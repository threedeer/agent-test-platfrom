---
name: api-auto-test
description: > API 接口全流程自动化测试技能。输入任意接口文档，自动执行：生成测试用例 → 初始化环境 → 生成测试脚本 → 运行测试 → 生成 HTML 报告（浏览器版 + 邮件版）→ 发送邮件。 触发关键词：跑接口测试、接口自动化、API 自动化、生成测试用例、生成测试报告、发测试报告邮件、 接口回归、run API tests、generate test cases、send test report email。 NOT for: 单元测试、UI/E2E 测试、性能压测。
---

# API Auto-Test

任意接口文档 → 测试用例 → 测试脚本 → 运行 → HTML 报告 → 邮件发送。

## 流程总览

```
API 文档
   ↓
test_cases.md          ← Step 1: 生成测试用例
   ↓
test_config.yaml       ← Step 2: 初始化环境（填充动态 ID）
   ↓
run_tests.py           ← Step 3: 生成测试脚本
   ↓
results.json           ← Step 4: 运行测试
   ↓
test_report.html       ← Step 5: 生成报告（浏览器版）
test_report_email.html ←         生成报告（邮件版）
   ↓
发邮件                 ← Step 6: scripts/send_test_report_email.py
```

## 技能文件

```
/api-auto-test/
├── SKILL.md                    # 技能文档
├── assets/                     # 模板和配置文件
│   ├── run_tests_template.py   # 测试脚本模板
│   ├── websocket_auth.py       # 大模型 WSS 动态鉴权生成器
│   ├── test_config.yaml        # 测试配置模板
│   └── email_config.yaml       # 邮件发送配置
├── scripts/                    # 工具脚本
│   ├── regen_report.py         # 浏览器版 HTML 报告生成器
│   ├── generate_email_report.py # 邮件版 HTML 报告生成器
│   └── send_test_report_email.py # 发送测试报告邮件
└── references/                 # 参考文档
    ├── tc-format.md            # 测试用例 Markdown 格式规范
    ├── config-schema.md        # test_config.yaml 完整 Schema
    └── email-html-rules.md     # 邮件 HTML 兼容性规则
```

---

## Step 1 — 生成测试用例（test_cases.md）

接受任意格式的接口文档：

| 输入形式 | 处理方式 |
|---------|---------|
| `.md` 文件路径 | `read` 读取 |
| OpenAPI / Swagger YAML/JSON | 解析 `paths` + `components` |
| URL | `web_fetch` 抓取 |
| 内联文本描述 | 从对话直接提取 |

**每个端点必须覆盖：**

1. 正向用例（合法参数，验证响应结构）
2. 缺少必填参数 → 400 / 非零业务码
3. 无效认证 → 401 / 403 / 非零业务码（如有认证）
4. 资源不存在 → 404 / 非零业务码（资源型端点）

**扩展覆盖（视文档详细程度）：** 枚举越界、重复创建（409）、上传限制（413/415）、权限隔离（403）、注入攻击（SQL/XSS）。

格式规范见 `references/tc-format.md`。

---

## Step 2 — 初始化测试环境（test_config.yaml）

调用真实 API 填充动态字段（session ID、资源 ID 等），写入 `test_config.yaml`。

配置 schema 及初始化模式见 `references/config-schema.md`。

**关键原则：**

- 破坏性操作（delete / reset）的目标 ID 在 init 时准备好
- 不存在的资源 ID 用固定字符串，如 `"nonexistent-id-000000"`
- 无效认证值固定填写，如 `"invalid_token_xyz"`
- **`project_name`、`api_version`、`base_url` 必须从接口文档中提取填写**，报告表头直接读取这三个字段：

```yaml
env:
  base_url: "http://localhost:8080"   # 接口文档 Base URL
  project_name: "File API"                  # 接口文档项目名
  api_version: "v1.0"                       # 接口文档版本号
```

**配置文件模板：**

```bash
# 复制模板到测试项目
cp /api-auto-test/assets/test_config.yaml ./test_config.yaml

# 根据实际接口修改配置
vim test_config.yaml
```

---

## Step 3 — 生成测试脚本（run_tests.py）

以 `assets/run_tests_template.py` 为基础，填入实际测试用例。

### 认证适配

模板支持 Cookie 和 Bearer Token 两种方式，按文档选择：

```python
# Cookie 认证
req.add_header("Cookie", effective_auth)

# Bearer Token 认证
req.add_header("Authorization", f"Bearer {effective_auth}")
```

### 非标准服务端行为适配

部分服务器不遵循 HTTP 语义，返回 `HTTP 200 + 非零业务码` 替代 `401/403/404`：

```python
# 认证失败断言（两种形式都接受）
def no_auth(status, resp):
    return status in (401, 403) or (status == 200 and resp.get("code", 0) != 0)

# 资源不存在断言
def not_found(status, resp):
    return status == 404 or (status == 200 and resp.get("code", 0) != 0)
```

模板已内置 `ok()` / `no_auth()` / `not_found()` / `bad_request()` 四个断言辅助函数。

### SSE (Server-Sent Events) 支持

模板已内置 SSE 流式接口测试支持，适用于 AI 对话、实时推送等场景。

**SSE 客户端 API：**

```python
# 创建 SSE 客户端（POST 请求）
sse = SSE_POST("/workflow/v1/debug/chat/completions",
               body={"flow_id": "...", "stream": True},
               headers={"x-consumer-username": "xxx"})

# 方式1：流式处理
for event in sse.stream(timeout=60, verbose=True):
    print(f"event: {event['event']}, data: {event['data']}")

# 方式2：收集所有事件
events = sse.collect(timeout=60, verbose=True)

# 方式3：直接获取拼接后的文本（AI 对话场景）
text = sse.collect_text(timeout=60)
```

**事件格式：**

```python
{
    "event": "message",      # 事件名
    "data": {"content": "..."},  # 解析后的 JSON（或原始字符串）
    "data_raw": "{\"content\":\"...\"}"  # 原始数据
}
```

**SSE 断言辅助：**

```python
# 检查是否包含指定事件
assert sse_has_event(events, "done")

# 检查是否有事件包含指定字段
assert sse_has_data_field(events, "content")

# 获取指定事件的所有 data
contents = sse_get_event_data(events, "message")
```

**SSE 测试用例示例：**

```python
def tc_02_sse_chat():
    def t001():
        body = {
            "flow_id": "XXXXXX",
            "uid": "test_user",
            "stream": True,
            "parameters": {"AGENT_USER_INPUT": "你好"}
        }
        headers = {"x-consumer-username": "appid"}

        sse = SSE_POST("/workflow/v1/debug/chat/completions", body=body, headers=headers)
        events = sse.collect(timeout=60, verbose=True)

        # 保存请求和响应数据到 TEST_DETAILS（用于生成详细报告）
        if TEST_DETAILS:
            TEST_DETAILS[-1]["request"] = body
            TEST_DETAILS[-1]["response"] = events

        assert len(events) > 0, "未收到任何 SSE 事件"
        assert not sse_has_event(events, "error"), "收到错误事件"

        return "PASS", f"共收到 {len(events)} 个事件"

    run("TC-02-001", "SSE 正常对话流式返回", "TC-02 SSE 流式对话", t001)
```

**重要提示：**
- 在测试用例中保存 `request` 和 `response` 到 `TEST_DETAILS[-1]`，这样生成的测试报告会包含完整的请求和响应数据
- 所有收到的 SSE 事件都会被完整记录，方便二次确认和调试

### WebSocket 支持

模板已内置 WebSocket 双向通信测试支持，适用于聊天、游戏、实时协作等场景。

**依赖安装：**

```bash
pip install websocket-client
```

**WebSocket 客户端 API：**

```python
# 创建 WebSocket 客户端
ws = WS("ws://localhost:8080/chat", headers={"Authorization": "Bearer token"})

# 建立连接
ws.connect()

# 发送消息
ws.send({"type": "hello", "data": "test"})

# 接收一条消息
msg = ws.receive(timeout=5)

# 接收所有消息（直到超时）
messages = ws.receive_all(timeout=5, max_messages=100)

# 关闭连接
ws.close()
```

**消息格式：**

```python
{
    "data": {"type": "response", "content": "..."},  # 解析后的 JSON（或原始字符串）
    "data_raw": "{\"type\":\"response\",\"content\":\"...\"}"  # 原始数据
}
```

**WebSocket 测试用例示例：**

```python
def tc_03_websocket_chat():
    def t001():
        """WebSocket 正常通信"""
        ws = WS("ws://localhost:8080/chat")
        ws.connect()
        
        # 发送消息
        ws.send({"type": "hello", "user": "test"})
        
        # 接收响应
        messages = ws.receive_all(timeout=5)
        
        ws.close()
        
        # 保存完整的通信记录到 TEST_DETAILS
        if TEST_DETAILS:
            TEST_DETAILS[-1]["request"] = {"type": "hello", "user": "test"}
            TEST_DETAILS[-1]["response"] = ws.get_log()  # 包含 connect/send/receive/close 的完整记录
        
        assert len(messages) > 0, "未收到任何消息"
        assert messages[0]["data"]["type"] == "welcome", "未收到欢迎消息"
        
        return "PASS", f"共收到 {len(messages)} 条消息"
    
    run("TC-03-001", "WebSocket 正常通信", "TC-03 WebSocket 测试", t001)
```

---

## 大模型 WSS 接口测试（动态鉴权）

**适用场景：** 讯飞星火等大模型 WebSocket 接口，需要动态生成 HMAC 签名认证。

**触发关键词：**
- "大模型 WSS 接口测试"
- "讯飞星火 WebSocket 测试"
- "动态鉴权 WebSocket"
- "大模型流式对话测试"

**与普通 WebSocket 测试的区别：**
- 普通 WebSocket：URL 固定，认证参数静态
- 大模型 WSS：URL 需要动态生成，HMAC 签名有时效性

### Step 1 — 准备配置文件

在 `test_config.yaml` 中配置大模型 API 信息：

```yaml
env:
  project_name: "讯飞星火 WebSocket API"
  api_version: "v2"
  base_url: "wss://spark-api.xf-yun.com/x2"  # 基础 URL（不含认证参数）

# 大模型 API 认证信息
llm_auth:
  api_key: "your_api_key_here"
  api_secret: "your_api_secret_here"
  app_id: "your_app_id_here"
```

### Step 2 — 动态生成鉴权 URL

**重要：** 大模型 WSS 接口的鉴权 URL 有时效性，每次测试前必须重新生成。

测试脚本会自动：
1. 从 `test_config.yaml` 读取 `llm_auth` 配置
2. 调用 `websocket_auth.py` 动态生成鉴权 URL
3. 使用生成的 `auth_url` 执行测试用例

**配置示例：**

```yaml
env:
  base_url: "wss://spark-api.xf-yun.com/x2"

llm_auth:
  api_key: "your_api_key"
  api_secret: "your_api_secret"
  app_id: "your_app_id"
```

**测试脚本中的自动鉴权：**

```python
def tc_01_llm_chat():
    def t001():
        """每次测试前动态生成鉴权 URL"""
        auth_url = generate_llm_auth_url()  # 自动从配置读取并生成
        
        ws = WS(auth_url)
        ws.connect()
        # ... 测试逻辑
```

### Step 3 — 编写测试用例

模板已内置大模型 WSS 测试用例示例，自动使用动态鉴权：

```python
def tc_03_llm_websocket_chat():
    """TC-03 大模型 WSS 接口测试（动态鉴权）"""
    # 检查是否配置了大模型认证信息
    if not LLM_API_KEY or not LLM_API_SECRET:
        print("  ⚠️  跳过大模型 WSS 测试：未配置 llm_auth")
        return
    
    def t001():
        """大模型正常对话请求"""
        # 动态生成鉴权 URL（每次测试都重新生成，避免过期）
        auth_url = generate_llm_auth_url()
        
        # 创建 WebSocket 连接
        ws = WS(auth_url)
        ws.connect()
        
        # 发送请求
        request = {
            "header": {"uid": "test_user", "app_id": LLM_APP_ID},
            "payload": {"message": {"text": [{"role": "user", "content": "你好"}]}},
            "parameter": {"chat": {"domain": "spark-x", "max_tokens": 4096}}
        }
        ws.send(request)
        
        # 接收流式响应
        messages = ws.receive_all(timeout=30)
        ws.close()
        
        # 保存通信记录
        if TEST_DETAILS:
            TEST_DETAILS[-1]["request"] = request
            TEST_DETAILS[-1]["response"] = ws.get_log()
        
        assert len(messages) > 0, "未收到任何响应"
        return "PASS", f"共收到 {len(messages)} 条消息"
    
    run("TC-03-001", "大模型正常对话", "TC-03 大模型 WSS 对话", t001)
```

**关键点：**
- `generate_llm_auth_url()` 自动从配置文件读取参数并生成鉴权 URL
- 每个测试用例内部调用，确保每次测试都使用新的鉴权
- 测试报告中只显示基础 URL，不暴露认证参数

---

**通信记录格式：**

```python
[
    {"type": "connect", "timestamp": 1774944397.123, "url": "ws://..."},
    {"type": "send", "timestamp": 1774944397.456, "data": {...}, "data_raw": "..."},
    {"type": "receive", "timestamp": 1774944397.789, "data": {...}, "data_raw": "..."},
    {"type": "close", "timestamp": 1774944398.012}
]
```

**重要提示：**
- 使用 `ws.get_log()` 获取完整的通信记录（包括连接、发送、接收、关闭）
- 所有消息都带时间戳，方便追踪通信时序
- 测试报告会显示完整的 WebSocket 通信过程

### 执行顺序

```python
# 普通模块正常顺序执行
tc_01_health()
tc_02_user(); time.sleep(2)
tc_03_order(); time.sleep(2)
# ...
# 破坏性模块（delete/reset）最后执行
tc_last_destructive()
teardown()   # 恢复环境
```

### 限速处理

```python
RATE_LIMIT_SLEEP = 0.5   # 每次请求间隔
# 模块间额外间隔：time.sleep(2)
# 轮询时直接用 _req() 而非 GET()，避免影响正常限速节奏
```

---

## Step 4 — 运行测试

```bash
python3 run_tests.py
```

**生成的文件：**

1. **results.json** - 测试结果摘要

```json
[
  {
    "id": "TC-01-001",
    "name": "服务健康时正常返回",
    "module": "TC-01 健康检查",
    "status": "PASS",
    "detail": "",
    "duration": 0.32
  }
]
```

`status` 枚举：`PASS` / `FAIL` / `ERROR` / `SKIP`

2. **test_report_sse.log** - SSE 测试详细日志

包含所有 SSE 测试用例的完整请求和响应数据（每一帧事件）。

3. **test_report_websocket.log** - WebSocket 测试详细日志

包含所有 WebSocket 测试用例的完整通信记录（connect/send/receive/close）。

**报告格式：**
```
测试汇总: 3 个用例
✅ 通过: 2 | ❌ 失败: 1 | 💥 错误: 0

用例 1: [TC-02-001] SSE 正常对话
📍 请求地址:
wss://spark-api.xf-yun.com/x2

📤 请求数据:
{完整的请求 JSON}

📥 响应数据:
共收到 10 个事件/消息:
#1: {完整的事件 JSON}
#2: {完整的事件 JSON}
...

✅ 测试结果: PASS (耗时: 0.27s)
```

**重要特性：**
- SSE 和 WebSocket 测试日志自动分离
- 所有用例都显示测试地址（只显示基础 URL）
- 所有用例的请求和响应数据都完整记录
- 每一帧/每条消息都详细输出
- 方便二次确认和调试

4. **test_report.html** - 浏览器版 HTML 报告（可选）

运行 `python3 generate_html_report.py` 生成。

5. **test_report_email.html** - 邮件版 HTML 报告（可选）

运行 `python3 generate_email_report.py` 生成。

---

## Step 5 — 生成报告

### 浏览器版（test_report.html）

```bash
# 在项目目录下直接运行（自动读取同目录 results.json 和 test_config.yaml）
python3 regen_report.py

# 也可显式指定路径
python3 regen_report.py results.json test_report.html
```

功能：统计卡片 + SVG 饼图 + 进度条 + 模块摘要 + Bug 列表 + 可筛选明细表格（JS 过滤）。

**报告表头**自动从同目录 `test_config.yaml` 的 `env.project_name`、`env.api_version`、`env.base_url` 读取，与接口文档保持一致。

**WebSocket 测试地址显示：**
- 报告 header 部分会显示测试地址
- 只显示基础 URL（如 `wss://spark-api.xf-yun.com/x2`）
- 不显示认证参数（host、date、authorization）

### 邮件版（test_report_email.html）

```bash
# 在项目目录下直接运行
python3 generate_email_report.py

# 也可显式指定路径
python3 generate_email_report.py results.json test_report_email.html
```

**严格遵循邮件 HTML 规范：**
- 无 JS、无 CSS class、无外部资源
- 全部内联 `style=`，`<table>` 布局
- SVG 饼图内联嵌入
- 最大宽度 660px
- 表头同样从 `test_config.yaml` 读取，**不会出现其他项目的名称/环境信息**
- WebSocket 测试地址同样只显示基础 URL

详细规范见 `references/email-html-rules.md`。

---

## Step 6 — 发送邮件报告

邮件配置文件：**技能目录**下的 `assets/email_config.yaml`（SMTP + 收件人）。

```bash
# 使用配置文件中的默认收件人
python3 send_test_report_email.py test_report_email.html

# 临时覆盖收件人 + 项目名
python3 send_test_report_email.py test_report_email.html \
    alice@company.com,bob@company.com "订单服务"
```

参数说明：

| 位置 | 含义 | 默认值 |
|------|------|--------|
| `$1` | 邮件版 HTML 报告路径 | `report.html` |
| `$2` | 收件人（逗号分隔，可选） | email_config.yaml 中的 to |
| `$3` | 项目名（可选） | `API` |

邮件主题示例：`📊 订单服务 接口自动化测试报告 2026-03-18`

修改 `assets/email_config.yaml` 适配项目（SMTP 地址、收件人列表、主题模板）。

---

## 工作目录结构

```
<project>/
├── test_config.yaml           # 环境配置 + 动态 ID（每次运行前初始化）
│                              # ⚠️ 必须包含 env.project_name / api_version / base_url
├── test_cases.md              # 测试用例说明文档
├── run_tests.py               # 测试脚本（基于 assets/run_tests_template.py）
├── regen_report.py            # 浏览器版报告生成器（从同目录运行）
├── generate_email_report.py   # 邮件版报告生成器（从同目录运行）
├── send_test_report_email.py  # 邮件发送脚本
├── results.json               # 原始结果（自动保存）
├── test_report.html           # 浏览器版报告
└── test_report_email.html     # 邮件版报告
```

> **报告表头来源**：`regen_report.py` 和 `generate_email_report.py` 均从同目录 `test_config.yaml` 的 `env` 节读取 `project_name`、`api_version`、`base_url`，**无需手动修改脚本**，换项目只需修改 `test_config.yaml`。

---

## 参考文件

| 文件 | 用途 |
|------|------|
| `assets/test_config.yaml` | 测试配置模板（复制到项目使用） |
| `assets/email_config.yaml` | SMTP + 收件人配置 |
| `assets/run_tests_template.py` | 测试脚本基础模板 |
| `assets/websocket_auth.py` | 大模型 WSS 动态鉴权生成器 |
| `scripts/send_test_report_email.py` | 邮件发送脚本 |
| `references/tc-format.md` | 测试用例 Markdown 表格格式规范 |
| `references/config-schema.md` | test_config.yaml 完整 schema |
| `references/email-html-rules.md` | 邮件 HTML 兼容性规则 |

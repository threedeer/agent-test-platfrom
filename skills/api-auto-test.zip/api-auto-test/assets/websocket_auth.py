#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
大模型 WebSocket 接口动态鉴权生成器

用于讯飞星火等大模型 WSS 接口的 HMAC 签名认证。
动态生成带鉴权参数的 WebSocket URL。

使用方式：
    python3 websocket_auth.py --url "wss://spark-api.xf-yun.com/x2" --api_key "xxx" --api_secret "xxx"
    
或作为模块导入：
    from websocket_auth import generate_auth_url
    url = generate_auth_url(base_url, api_key, api_secret)
"""

import argparse
import hmac
import hashlib
import base64
from datetime import datetime, timezone
from urllib.parse import urlencode, quote


def generate_auth_url(base_url: str, api_key: str, api_secret: str) -> str:
    """
    生成带鉴权参数的 WebSocket URL
    
    Args:
        base_url: 基础 WebSocket URL（如 wss://spark-api.xf-yun.com/x2）
        api_key: API Key
        api_secret: API Secret
    
    Returns:
        带鉴权参数的完整 WebSocket URL
    """
    # 解析 host 和 path
    from urllib.parse import urlparse
    parsed = urlparse(base_url)
    host = parsed.netloc
    path = parsed.path or "/"
    
    # 生成 RFC 1123 格式的时间戳
    date = datetime.now(timezone.utc).strftime('%a, %d %b %Y %H:%M:%S GMT')
    
    # 拼接签名原文（注意：第三行不包含 "request-line:" 前缀）
    signature_origin = f"host: {host}\ndate: {date}\nGET {path} HTTP/1.1"
    
    # 计算 HMAC-SHA256 签名
    signature_sha = hmac.new(
        api_secret.encode('utf-8'),
        signature_origin.encode('utf-8'),
        hashlib.sha256
    ).digest()
    
    signature_sha_base64 = base64.b64encode(signature_sha).decode('utf-8')
    
    # 拼接 authorization
    authorization_origin = f'api_key="{api_key}", algorithm="hmac-sha256", headers="host date request-line", signature="{signature_sha_base64}"'
    authorization = base64.b64encode(authorization_origin.encode('utf-8')).decode('utf-8')
    
    # URL 编码（使用 + 作为空格编码，符合讯飞星火要求）
    date_encoded = quote(date, safe='').replace('%20', '+')
    authorization_encoded = quote(authorization, safe='').replace('%20', '+')
    
    # 拼接完整 URL
    auth_url = f"{base_url}?host={host}&date={date_encoded}&authorization={authorization_encoded}"
    
    return auth_url


def main():
    parser = argparse.ArgumentParser(description='大模型 WebSocket 接口动态鉴权生成器')
    parser.add_argument('--url', required=True, help='基础 WebSocket URL（如 wss://spark-api.xf-yun.com/x2）')
    parser.add_argument('--api_key', required=True, help='API Key')
    parser.add_argument('--api_secret', required=True, help='API Secret')
    parser.add_argument('--output', choices=['url', 'json'], default='url', help='输出格式：url 或 json')
    
    args = parser.parse_args()
    
    auth_url = generate_auth_url(args.url, args.api_key, args.api_secret)
    
    if args.output == 'json':
        import json
        print(json.dumps({
            "base_url": args.url,
            "auth_url": auth_url,
            "api_key": args.api_key,
            "generated_at": datetime.now().isoformat()
        }, ensure_ascii=False, indent=2))
    else:
        print(auth_url)


if __name__ == '__main__':
    main()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
API Auto-Test Runner Template
==============================
使用步骤：
1. 复制到测试项目根目录，重命名为 run_tests.py
2. 在 test_config.yaml 中填写 env.base_url 和认证信息
3. 实现各模块的测试用例函数
4. 运行：python3 run_tests.py

结果保存至 results.json，再运行报告生成脚本生成 HTML。
"""

import json, os, sys, time, traceback, yaml, datetime
import urllib.request, urllib.parse, urllib.error, ssl
from typing import Generator, Optional, Dict, List, Any

SCRIPT_DIR  = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(SCRIPT_DIR, "test_config.yaml")

# ── 加载配置 ──────────────────────────────────────────────────────────────
with open(CONFIG_PATH, encoding="utf-8") as f:
    CFG = yaml.safe_load(f)

BASE = CFG["env"]["base_url"]

# 认证方式：根据文档选择其一，删除不用的
COOKIE        = CFG["env"].get("cookie", "")
TOKEN         = CFG["env"].get("token", "")
INVALID_AUTH  = CFG["env"].get("invalid_cookie", CFG["env"].get("invalid_token", "invalid"))

# 大模型 WSS 接口认证（动态鉴权）
LLM_AUTH = CFG.get("llm_auth", {})
LLM_API_KEY = LLM_AUTH.get("api_key", "")
LLM_API_SECRET = LLM_AUTH.get("api_secret", "")
LLM_APP_ID = LLM_AUTH.get("app_id", "")

# 动态鉴权生成器（仅用于大模型 WSS 接口）
def generate_llm_auth_url():
    """动态生成大模型 WSS 接口的鉴权 URL"""
    if not LLM_API_KEY or not LLM_API_SECRET:
        raise ValueError("大模型 WSS 接口需要配置 llm_auth.api_key 和 llm_auth.api_secret")
    
    # 导入鉴权生成器（与配置文件同目录）
    sys.path.insert(0, os.path.join(SCRIPT_DIR, "assets") if os.path.exists(os.path.join(SCRIPT_DIR, "assets")) else SCRIPT_DIR)
    from websocket_auth import generate_auth_url
    
    return generate_auth_url(BASE, LLM_API_KEY, LLM_API_SECRET)

# ── 限速 ──────────────────────────────────────────────────────────────────
RATE_LIMIT_SLEEP = 0.5   # 每次请求间隔（秒），防止触发 429

def _throttle():
    time.sleep(RATE_LIMIT_SLEEP)

# ── HTTP 核心 ─────────────────────────────────────────────────────────────
_SSL_CTX = ssl.create_default_context()
_SSL_CTX.check_hostname = False
_SSL_CTX.verify_mode    = ssl.CERT_NONE

def _encode_path(path: str) -> str:
    """对 URL querystring 中的非 ASCII 字符（如中文）进行 percent-encode。"""
    if "?" not in path:
        return path
    base, qs = path.split("?", 1)
    parts = []
    for kv in qs.split("&"):
        if "=" in kv:
            k, v = kv.split("=", 1)
            parts.append(f"{k}={urllib.parse.quote(v, safe='')}")
        else:
            parts.append(kv)
    return base + "?" + "&".join(parts)

def _req(method: str, url: str, body=None,
         auth: str = None, content_type: str = "application/json"):
    """
    发起 HTTP 请求，返回 (status_code, response_dict)。
    auth: 覆盖默认认证；传 "" 表示不带认证（测试 401）。
    """
    _throttle()
    data = None
    if body is not None:
        data = (json.dumps(body) if isinstance(body, dict) else str(body)).encode("utf-8")

    req = urllib.request.Request(url, data=data, method=method)

    # 设置认证头（按项目选择 Cookie 或 Bearer Token）
    effective_auth = auth if auth is not None else (COOKIE or TOKEN)
    if effective_auth:
        if COOKIE and not TOKEN:
            req.add_header("Cookie", effective_auth)
        else:
            req.add_header("Authorization", f"Bearer {effective_auth}")

    if content_type and data:
        req.add_header("Content-Type", content_type)

    try:
        with urllib.request.urlopen(req, context=_SSL_CTX, timeout=35) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
            try:    return resp.status, json.loads(raw)
            except: return resp.status, {"_raw": raw}
    except urllib.error.HTTPError as e:
        raw = e.read().decode("utf-8", errors="replace")
        try:    return e.code, json.loads(raw)
        except: return e.code, {"_raw": raw}
    except Exception as e:
        return 0, {"_error": str(e)}

def GET   (path, auth=None):        return _req("GET",    BASE + _encode_path(path), auth=auth)
def POST  (path, body=None, auth=None): return _req("POST",   BASE + path, body=body, auth=auth)
def PATCH (path, body=None, auth=None): return _req("PATCH",  BASE + path, body=body, auth=auth)
def PUT   (path, body=None, auth=None): return _req("PUT",    BASE + path, body=body, auth=auth)
def DELETE(path, auth=None):        return _req("DELETE",  BASE + path, auth=auth)

# ── 断言辅助 ──────────────────────────────────────────────────────────────
def ok(status: int, resp: dict, expected_http=200) -> bool:
    """正向断言：HTTP 状态码符合预期，业务码为 0（如有 code 字段）。"""
    if status != expected_http:
        return False
    if "code" in resp:
        return resp["code"] == 0
    return True

def no_auth(status: int, resp: dict) -> bool:
    """
    认证失败断言：接受 HTTP 401/403，
    也接受服务端返回 HTTP 200 + 非零业务码（非标准但常见）。
    """
    if status in (401, 403):
        return True
    if status == 200 and resp.get("code", 0) != 0:
        return True
    return False

def not_found(status: int, resp: dict) -> bool:
    """
    资源不存在断言：接受 HTTP 404，
    也接受服务端返回 HTTP 200 + 非零业务码（非标准但常见）。
    """
    if status == 404:
        return True
    if status == 200 and resp.get("code", 0) != 0:
        return True
    return False

def bad_request(status: int, resp: dict) -> bool:
    """参数错误断言：接受 HTTP 400，也接受 HTTP 200 + 非零业务码。"""
    if status == 400:
        return True
    if status == 200 and resp.get("code", 0) != 0:
        return True
    return False

# ── SSE (Server-Sent Events) 支持 ───────────────────────────────────────
class SSEClient:
    """
    SSE 客户端，支持 POST 请求触发流式响应。

    用法:
        sse = SSEClient(BASE, "/workflow/v1/debug/chat/completions",
                        headers={"x-consumer-username": "xxx"},
                        body={"flow_id": "...", "stream": True})
        for event in sse.stream(timeout=60):
            print(f"event: {event['event']}, data: {event['data']}")

        # 或获取所有事件后断言
        events = sse.collect(timeout=60)
        assert any(e["event"] == "done" for e in events)
    """

    def __init__(self, base_url: str, path: str,
                 body: Optional[Dict] = None,
                 headers: Optional[Dict[str, str]] = None,
                 method: str = "POST"):
        self.url = base_url + path
        self.body = body or {}
        self.headers = headers or {}
        self.method = method
        self._conn = None
        self._buffer = ""

    def _build_request(self) -> urllib.request.Request:
        """构建请求对象"""
        data = json.dumps(self.body).encode("utf-8") if self.body else None
        req = urllib.request.Request(self.url, data=data, method=self.method)

        # 设置自定义 headers
        for k, v in self.headers.items():
            req.add_header(k, v)

        # 设置认证头（按项目选择 Cookie 或 Bearer Token）
        effective_auth = COOKIE or TOKEN
        if effective_auth:
            if COOKIE and not TOKEN:
                req.add_header("Cookie", effective_auth)
            else:
                req.add_header("Authorization", f"Bearer {effective_auth}")

        if data:
            req.add_header("Content-Type", "application/json")

        # SSE 必须的 headers
        req.add_header("Accept", "text/event-stream")
        req.add_header("Cache-Control", "no-cache")

        return req

    def _parse_event(self, raw: str) -> Optional[Dict[str, Any]]:
        """
        解析单个 SSE 事件。

        SSE 格式:
            event: message
            data: {"key": "value"}

            event: done
            data: [DONE]
        """
        lines = raw.strip().split("\n")
        event_name = "message"
        data_lines = []

        for line in lines:
            line = line.strip()
            if line.startswith("event:"):
                event_name = line[6:].strip()
            elif line.startswith("data:"):
                data_lines.append(line[5:].strip())
            elif line == "":
                continue

        if not data_lines:
            return None

        data_raw = "\n".join(data_lines)

        # 尝试解析 JSON
        data_parsed = None
        try:
            data_parsed = json.loads(data_raw)
        except json.JSONDecodeError:
            data_parsed = data_raw  # 保留原始字符串

        return {
            "event": event_name,
            "data": data_parsed,
            "data_raw": data_raw
        }

    def stream(self, timeout: int = 60, verbose: bool = False) -> Generator[Dict[str, Any], None, None]:
        """
        流式读取 SSE 事件。

        Args:
            timeout: 超时时间（秒）
            verbose: 是否打印每个事件

        Yields:
            {"event": str, "data": dict/str, "data_raw": str}
        """
        req = self._build_request()

        try:
            self._conn = urllib.request.urlopen(req, context=_SSL_CTX, timeout=timeout)
            self._buffer = ""

            while True:
                chunk = self._conn.read(1024)
                if not chunk:
                    break

                self._buffer += chunk.decode("utf-8", errors="replace")

                # 尝试解析完整事件（以双换行分隔）
                while "\n\n" in self._buffer:
                    event_raw, self._buffer = self._buffer.split("\n\n", 1)
                    event = self._parse_event(event_raw)
                    if event:
                        if verbose:
                            print(f"  📨 SSE event: {event['event']}")
                            print(f"     data: {event['data_raw'][:200]}{'...' if len(event['data_raw']) > 200 else ''}")
                        yield event

        except urllib.error.HTTPError as e:
            raw = e.read().decode("utf-8", errors="replace")
            try:
                error_data = json.loads(raw)
            except:
                error_data = {"_raw": raw}
            yield {"event": "error", "data": error_data, "data_raw": raw, "http_status": e.code}

        except Exception as e:
            yield {"event": "error", "data": {"_error": str(e)}, "data_raw": str(e)}

        finally:
            if self._conn:
                self._conn.close()

    def collect(self, timeout: int = 60, verbose: bool = False,
                max_events: int = 1000) -> List[Dict[str, Any]]:
        """
        收集所有 SSE 事件并返回列表。

        Args:
            timeout: 超时时间（秒）
            verbose: 是否打印每个事件
            max_events: 最大事件数（防止无限循环）

        Returns:
            [{"event": str, "data": dict/str, "data_raw": str}, ...]
        """
        events = []
        for event in self.stream(timeout=timeout, verbose=verbose):
            events.append(event)
            if len(events) >= max_events:
                break
            # 检测结束标记
            if event.get("event") == "done" or event.get("data_raw") == "[DONE]":
                break
        return events

    def collect_text(self, timeout: int = 60, verbose: bool = False) -> str:
        """
        收集 SSE 流中的所有文本内容（适用于 AI 对话场景）。

        假设每个事件的 data.content 字段包含文本片段，拼接返回。
        """
        events = self.collect(timeout=timeout, verbose=verbose)
        text_parts = []
        for e in events:
            data = e.get("data")
            if isinstance(data, dict):
                # 常见字段: content, text, delta.content, choices[0].delta.content
                content = data.get("content") or data.get("text")
                if not content:
                    delta = data.get("delta", {})
                    content = delta.get("content") or delta.get("text")
                if not content:
                    choices = data.get("choices", [])
                    if choices:
                        delta = choices[0].get("delta", {})
                        content = delta.get("content") or delta.get("text")
                if content:
                    text_parts.append(content)
        return "".join(text_parts)


def SSE_POST(path: str, body: Optional[Dict] = None,
             headers: Optional[Dict[str, str]] = None) -> SSEClient:
    """
    创建 SSE 客户端（POST 请求）。

    用法:
        sse = SSE_POST("/workflow/v1/debug/chat/completions", body={...})
        events = sse.collect(timeout=60, verbose=True)
    """
    return SSEClient(BASE, path, body=body, headers=headers, method="POST")


def SSE_GET(path: str, headers: Optional[Dict[str, str]] = None) -> SSEClient:
    """
    创建 SSE 客户端（GET 请求）。
    """
    return SSEClient(BASE, path, headers=headers, method="GET")


# ── SSE 断言辅助 ─────────────────────────────────────────────────────────
def sse_has_event(events: List[Dict], event_name: str) -> bool:
    """检查事件列表中是否包含指定事件名"""
    return any(e.get("event") == event_name for e in events)


def sse_has_data_field(events: List[Dict], field: str) -> bool:
    """检查事件列表中是否有事件的 data 包含指定字段"""
    for e in events:
        data = e.get("data")
        if isinstance(data, dict) and field in data:
            return True
    return False


def sse_get_event_data(events: List[Dict], event_name: str) -> List[Any]:
    """获取指定事件名的所有 data"""
    return [e["data"] for e in events if e.get("event") == event_name]


# ── WebSocket 支持 ──────────────────────────────────────────────────────
try:
    import websocket
    WEBSOCKET_AVAILABLE = True
except ImportError:
    WEBSOCKET_AVAILABLE = False
    print("⚠️  websocket-client 未安装，WebSocket 测试不可用")
    print("   安装: pip install websocket-client")

class WebSocketClient:
    """
    WebSocket 客户端，支持双向实时通信。
    
    用法:
        ws = WebSocketClient("ws://localhost:8080/chat")
        ws.connect()
        ws.send({"type": "hello", "data": "test"})
        messages = ws.receive_all(timeout=5)
        ws.close()
        
        # 获取完整的通信记录
        log = ws.get_log()
    """
    
    def __init__(self, url: str, headers: Optional[Dict[str, str]] = None):
        if not WEBSOCKET_AVAILABLE:
            raise ImportError("websocket-client 未安装")
        self.url = url
        self.headers = headers or {}
        self.ws = None
        self.log = []  # 记录所有通信
    
    def connect(self, timeout: int = 10):
        """建立 WebSocket 连接"""
        self.ws = websocket.create_connection(
            self.url,
            header=self.headers,
            timeout=timeout
        )
        self.log.append({
            "type": "connect",
            "timestamp": time.time(),
            "url": self.url
        })
    
    def send(self, data):
        """发送消息（支持 dict 或 str）"""
        if isinstance(data, dict):
            data_str = json.dumps(data)
        else:
            data_str = data
        
        self.ws.send(data_str)
        self.log.append({
            "type": "send",
            "timestamp": time.time(),
            "data": data if isinstance(data, dict) else data_str,
            "data_raw": data_str
        })
    
    def receive(self, timeout: int = 5) -> Optional[Dict]:
        """接收一条消息"""
        self.ws.settimeout(timeout)
        try:
            raw = self.ws.recv()
            try:
                parsed = json.loads(raw)
                msg = {"data": parsed, "data_raw": raw}
            except:
                msg = {"data": raw, "data_raw": raw}
            
            self.log.append({
                "type": "receive",
                "timestamp": time.time(),
                "data": msg["data"],
                "data_raw": msg["data_raw"]
            })
            return msg
        except:
            return None
    
    def receive_all(self, timeout: int = 5, max_messages: int = 100) -> List[Dict]:
        """接收所有消息直到超时"""
        messages = []
        while len(messages) < max_messages:
            msg = self.receive(timeout=1)
            if msg is None:
                break
            messages.append(msg)
        return messages
    
    def close(self):
        """关闭连接"""
        if self.ws:
            self.ws.close()
            self.log.append({
                "type": "close",
                "timestamp": time.time()
            })
    
    def get_log(self) -> List[Dict]:
        """获取完整的通信记录"""
        return self.log

def WS(url: str, headers: Optional[Dict[str, str]] = None) -> WebSocketClient:
    """创建 WebSocket 客户端"""
    return WebSocketClient(url, headers=headers)


# ── 轮询辅助 ─────────────────────────────────────────────────────────────
def poll_until(check_fn, interval=5, max_s=120) -> bool:
    """
    轮询直到 check_fn() 返回 True。
    check_fn 应直接调用 _req()，而非 GET()/POST()，避免影响限速计数。

    示例：
        poll_until(lambda: _req("GET", BASE+f"/jobs/{job_id}")[1]
                            .get("data",{}).get("status") == "done")
    """
    for _ in range(max_s // interval):
        time.sleep(interval)
        if check_fn():
            return True
    return False

# ── 运行器 ────────────────────────────────────────────────────────────────
RESULTS: list[dict] = []
TEST_DETAILS: list[dict] = []  # 记录测试详情（用于生成详细报告）

def run(tc_id: str, name: str, module: str, fn):
    """
    执行一条测试用例，捕获异常，记录结果。
    fn 应返回 ("PASS"|"FAIL"|"SKIP"|"ERROR", detail_str)。
    """
    t0 = time.time()
    status, detail = "ERROR", ""
    test_detail = {
        "id": tc_id,
        "name": name,
        "module": module,
        "request": None,
        "response": None,
        "status": "ERROR",
        "detail": ""
    }
    
    # 先添加到列表，这样测试函数中可以通过 TEST_DETAILS[-1] 访问
    TEST_DETAILS.append(test_detail)
    
    try:
        result = fn()
        if isinstance(result, tuple) and len(result) == 2:
            status, detail = result
        else:
            status = str(result); detail = ""
    except AssertionError as e:
        status, detail = "FAIL", str(e)
    except Exception:
        status, detail = "ERROR", traceback.format_exc().strip()
    
    dur = round(time.time() - t0, 2)
    
    # 更新测试详情
    TEST_DETAILS[-1]["status"] = status
    TEST_DETAILS[-1]["detail"] = detail
    TEST_DETAILS[-1]["duration"] = dur
    
    RESULTS.append({"id": tc_id, "name": name, "module": module,
                    "status": status, "detail": detail or "", "duration": dur})
    icon = {"PASS":"✅","FAIL":"❌","ERROR":"💥","SKIP":"⏭"}.get(status,"?")
    print(f"  {icon} [{tc_id}] {name}  ({dur}s)")
    if detail and status != "PASS":
        print(f"      {detail}")


# ════════════════════════════════════════════════════════════════════════
# 初始化（可选）
# 运行测试前调用真实 API 填充 test_config.yaml 中的动态 ID
# ════════════════════════════════════════════════════════════════════════

def initialize_env():
    """
    调用真实 API，填充 CFG 中的动态字段（session_id、resource_id 等）。
    填充完成后写回 test_config.yaml。
    按项目需要修改此函数。
    """
    print("🔧 初始化测试环境...")
    # 示例：健康检查
    s, r = GET("/health")
    assert s == 200, f"服务不可达: {s} {r}"
    print("   ✅ 服务健康")

    # 示例：获取主资源 ID
    # s, r = GET("/resource/list")
    # CFG["resources"]["main_resource_id"] = r["data"]["list"][0]["id"]

    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        yaml.dump(CFG, f, allow_unicode=True, default_flow_style=False)
    print("   ✅ 配置已更新")


# ════════════════════════════════════════════════════════════════════════
# 测试用例实现
# 每个模块一个函数，函数内调用 run() 注册用例
#
# 示例：
#   def tc_01_health():
#       def t001():
#           s, r = GET("/health")
#           assert ok(s, r), f"健康检查失败: {r}"
#           assert r["data"]["status"] == "healthy"
#           return "PASS", ""
#       run("TC-01-001", "服务健康时返回 healthy", "TC-01 健康检查", t001)
#
#       def t002():
#           return "SKIP", "需要模拟 MySQL 断开（环境限制）"
#       run("TC-01-002", "依赖服务不可达时返回 unhealthy", "TC-01 健康检查", t002)
# ════════════════════════════════════════════════════════════════════════

def tc_01_health():
    """TC-01 健康检查（示例，替换为实际测试）"""
    def t001():
        s, r = GET("/health")
        assert ok(s, r), f"健康检查失败: status={s}, resp={r}"
        return "PASS", ""
    run("TC-01-001", "服务健康时正常返回", "TC-01 健康检查", t001)


def tc_02_sse_chat():
    """TC-02 SSE 流式对话测试（示例）"""
    def t001():
        """SSE 正向用例：正常对话流式返回"""
        body = {
            "flow_id": "7424650520685490176",
            "uid": "test_user_001",
            "stream": True,
            "chat_id": "test_chat_001",
            "history": [
                {"role": "user", "content_type": "text", "content": "你好"},
                {"role": "assistant", "content_type": "text", "content": "你好，我是你的工作助手"}
            ],
            "parameters": {
                "AGENT_USER_INPUT": "测试问题"
            }
        }
        headers = {"x-consumer-username": "bc4dfddc"}

        sse = SSE_POST("/workflow/v1/debug/chat/completions", body=body, headers=headers)
        events = sse.collect(timeout=60, verbose=True)

        # 断言：至少收到一个事件
        assert len(events) > 0, "未收到任何 SSE 事件"

        # 断言：没有错误事件
        error_events = [e for e in events if e.get("event") == "error"]
        assert len(error_events) == 0, f"收到错误事件: {error_events}"

        # 断言：收到有效数据（根据实际接口调整）
        # 例如：检查是否有 content 字段
        has_content = False
        for e in events:
            data = e.get("data")
            if isinstance(data, dict) and ("content" in data or "text" in data):
                has_content = True
                break

        assert has_content, "未收到有效的对话内容"

        return "PASS", f"共收到 {len(events)} 个事件"

    run("TC-02-001", "SSE 正常对话流式返回", "TC-02 SSE 流式对话", t001)

    def t002():
        """SSE 负向用例：缺少必填参数"""
        body = {
            "flow_id": "7424650520685490176",
            # 缺少 uid
            "stream": True,
        }
        headers = {"x-consumer-username": "bc4dfddc"}

        sse = SSE_POST("/workflow/v1/debug/chat/completions", body=body, headers=headers)
        events = sse.collect(timeout=30, verbose=True)

        # 断言：应该返回错误
        error_events = [e for e in events if e.get("event") == "error"]
        assert len(error_events) > 0, "缺少必填参数时应返回错误"

        return "PASS", f"正确返回错误: {error_events[0].get('data')}"

    run("TC-02-002", "SSE 缺少必填参数返回错误", "TC-02 SSE 流式对话", t002)

    def t003():
        """SSE 负向用例：无效认证"""
        body = {
            "flow_id": "7424650520685490176",
            "uid": "test_user_001",
            "stream": True,
        }
        headers = {"x-consumer-username": "invalid_user_xxx"}

        sse = SSE_POST("/workflow/v1/debug/chat/completions", body=body, headers=headers)
        events = sse.collect(timeout=30, verbose=True)

        # 断言：应该返回认证错误
        error_events = [e for e in events if e.get("event") == "error"]
        http_status = error_events[0].get("http_status") if error_events else None

        assert http_status in (401, 403) or len(error_events) > 0, "无效认证时应返回错误"

        return "PASS", f"正确返回认证错误: HTTP {http_status}"

    run("TC-02-003", "SSE 无效认证返回错误", "TC-02 SSE 流式对话", t003)


def tc_03_llm_websocket_chat():
    """TC-03 大模型 WSS 接口测试（动态鉴权）"""
    # 检查是否配置了大模型认证信息
    if not LLM_API_KEY or not LLM_API_SECRET:
        print("  ⚠️  跳过大模型 WSS 测试：未配置 llm_auth")
        return
    
    def t001():
        """大模型正常对话请求"""
        # 动态生成鉴权 URL（每次测试都重新生成，避免过期）
        auth_url = generate_llm_auth_url()
        
        # 创建 WebSocket 连接
        ws = WS(auth_url)
        ws.connect()
        
        # 发送请求
        request = {
            "header": {
                "uid": "test_user",
                "app_id": LLM_APP_ID
            },
            "payload": {
                "message": {
                    "text": [
                        {"role": "user", "content": "你好"}
                    ]
                }
            },
            "parameter": {
                "chat": {
                    "domain": "spark-x",
                    "max_tokens": 4096
                }
            }
        }
        ws.send(request)
        
        # 接收流式响应
        messages = ws.receive_all(timeout=30)
        
        ws.close()
        
        # 保存通信记录
        if TEST_DETAILS:
            TEST_DETAILS[-1]["request"] = request
            TEST_DETAILS[-1]["response"] = ws.get_log()
        
        assert len(messages) > 0, "未收到任何响应"
        
        return "PASS", f"共收到 {len(messages)} 条消息"
    
    run("TC-03-001", "大模型正常对话", "TC-03 大模型 WSS 对话", t001)

    def t002():
        """大模型空消息请求"""
        auth_url = generate_llm_auth_url()
        
        ws = WS(auth_url)
        ws.connect()
        
        # 发送空请求
        ws.send({})
        messages = ws.receive_all(timeout=10)
        
        ws.close()
        
        if TEST_DETAILS:
            TEST_DETAILS[-1]["request"] = {}
            TEST_DETAILS[-1]["response"] = ws.get_log()
        
        # 应该返回错误
        return "PASS", "正确处理空请求"
    
    run("TC-03-002", "大模型空消息请求", "TC-03 大模型 WSS 对话", t002)


# ════════════════════════════════════════════════════════════════════════
# 环境恢复（可选）
# 如果测试中有破坏性操作（delete/reset），在此恢复
# ════════════════════════════════════════════════════════════════════════

def teardown():
    """测试结束后恢复环境（按需实现）。"""
    pass


# ── 主入口 ────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    start = datetime.datetime.now()
    print("=" * 60)
    print("  API 全量测试")
    print(f"  环境: {BASE}")
    print(f"  开始: {start.strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)

    # 初始化（如需要）
    # initialize_env()

    # 运行各模块（破坏性用例放最后）
    tc_01_health()
    tc_02_sse_chat(); time.sleep(2)
    tc_03_llm_websocket_chat(); time.sleep(2)
    # tc_04_xxx(); time.sleep(2)
    # ...
    # tc_last_destructive()

    # 环境恢复
    teardown()

    # 保存结果
    results_path = os.path.join(SCRIPT_DIR, "results.json")
    with open(results_path, "w", encoding="utf-8") as f:
        json.dump(RESULTS, f, ensure_ascii=False, indent=2)

    # 汇总输出
    total    = len(RESULTS)
    passed   = sum(1 for r in RESULTS if r["status"] == "PASS")
    failed   = sum(1 for r in RESULTS if r["status"] == "FAIL")
    errors   = sum(1 for r in RESULTS if r["status"] == "ERROR")
    skipped  = sum(1 for r in RESULTS if r["status"] == "SKIP")
    executed = total - skipped
    rate     = round(passed / executed * 100, 1) if executed else 0
    elapsed  = round((datetime.datetime.now() - start).total_seconds(), 1)

    print("\n" + "=" * 60)
    print(f"  总计:{total}  通过:{passed}  失败:{failed}  错误:{errors}  跳过:{skipped}")
    print(f"  通过率:{rate}%  (执行 {executed} 条)  耗时:{elapsed}s")
    print("=" * 60)
    print(f"\n💾 结果已保存: {results_path}")
    
    # 生成详细测试报告（分离 SSE 和 WebSocket）
    def is_sse_test(detail):
        """判断是否为 SSE 测试"""
        resp = detail.get("response")
        if isinstance(resp, list) and len(resp) > 0:
            first = resp[0]
            return isinstance(first, dict) and "event" in first
        return False
    
    def is_websocket_test(detail):
        """判断是否为 WebSocket 测试"""
        resp = detail.get("response")
        if isinstance(resp, list) and len(resp) > 0:
            first = resp[0]
            return isinstance(first, dict) and "type" in first and first.get("type") in ["connect", "send", "receive", "close"]
        return False
    
    def generate_report(details, filename, title):
        """生成测试报告"""
        if not details:
            return
        
        report_path = os.path.join(SCRIPT_DIR, filename)
        with open(report_path, "w", encoding="utf-8") as f:
            f.write("=" * 80 + "\n")
            f.write(f"{title}\n")
            f.write(f"生成时间: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write("=" * 80 + "\n\n")
            
            test_total = len(details)
            test_passed = sum(1 for d in details if d["status"] == "PASS")
            test_failed = sum(1 for d in details if d["status"] == "FAIL")
            test_errors = sum(1 for d in details if d["status"] == "ERROR")
            
            f.write(f"测试汇总: {test_total} 个用例\n")
            f.write(f"✅ 通过: {test_passed} | ❌ 失败: {test_failed} | 💥 错误: {test_errors}\n")
            f.write("=" * 80 + "\n\n")
            
            for idx, detail in enumerate(details, 1):
                f.write(f"用例 {idx}: [{detail['id']}] {detail['name']}\n")
                f.write("-" * 80 + "\n")
                
                # 请求地址（只显示基础 URL）
                f.write("📍 请求地址:\n")
                if is_websocket_test(detail):
                    # WebSocket 测试：显示基础 URL（不含认证参数）
                    ws_base = BASE if BASE.startswith("ws://") or BASE.startswith("wss://") else BASE
                    f.write(f"{ws_base}\n\n")
                else:
                    # HTTP/SSE 测试：显示基础 URL
                    f.write(f"{BASE}\n\n")
                
                # 请求数据
                f.write("📤 请求数据:\n")
                if detail.get("request"):
                    f.write(json.dumps(detail["request"], ensure_ascii=False, indent=2) + "\n\n")
                else:
                    f.write("(未记录)\n\n")
                
                # 响应数据
                f.write("📥 响应数据:\n")
                if detail.get("response") is not None:
                    resp = detail["response"]
                    if len(resp) == 0:
                        f.write("未收到任何响应\n")
                    else:
                        f.write(f"共收到 {len(resp)} 个事件/消息:\n\n")
                        for i, item in enumerate(resp, 1):
                            f.write(f"#{i}:\n")
                            f.write(json.dumps(item, ensure_ascii=False, indent=2) + "\n\n")
                else:
                    if detail["status"] == "PASS":
                        f.write(f"{detail['detail']}\n")
                    else:
                        f.write(f"测试失败: {detail['detail']}\n")
                
                # 测试结果
                status_icon = {"PASS":"✅","FAIL":"❌","ERROR":"💥","SKIP":"⏭"}.get(detail["status"],"?")
                f.write(f"\n{status_icon} 测试结果: {detail['status']} (耗时: {detail['duration']}s)\n")
                f.write("=" * 80 + "\n\n")
        
        print(f"📄 {title}已生成: {report_path}")
    
    # 分离 SSE 和 WebSocket 测试
    sse_details = [d for d in TEST_DETAILS if is_sse_test(d)]
    ws_details = [d for d in TEST_DETAILS if is_websocket_test(d)]
    
    if sse_details:
        generate_report(sse_details, "test_report_sse.log", "SSE 测试报告")
    
    if ws_details:
        generate_report(ws_details, "test_report_websocket.log", "WebSocket 测试报告")
    
    print("   下一步:")
    print("     python3 regen_report.py          # 浏览器版 HTML 报告")
    print("     python3 generate_email_report.py  # 邮件版 HTML 报告")

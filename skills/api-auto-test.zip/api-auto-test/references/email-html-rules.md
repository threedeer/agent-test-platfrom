# 邮件 HTML 兼容性规则

生成的邮件报告必须在 Outlook、Gmail、企业邮箱（飞书邮件、企业微信邮件）和 QQ 邮箱中正确渲染。

## 硬性规则（必须遵守）

| 规则 | 原因 |
|------|------|
| **禁用 `<script>`** | 所有邮件客户端都会剥离 |
| **禁用 CSS `class=`** | 外部/内嵌样式表常被剥离 |
| **禁用 `<head>` 内 `<style>`** | Gmail 会剥离 `<head>` 样式 |
| **所有样式内联** | `style="..."` 写在每个元素上 |
| **禁用 flexbox / CSS grid** | Outlook 不支持 |
| **禁用 `position:absolute/fixed`** | 多数客户端忽略 |
| **使用 `<table>` 布局** | 兼容性最强 |
| **禁用外部图片/字体** | 可能被拦截；图表用内联 SVG |
| **最大宽度 660px** | 适配所有屏幕，不出现横向滚动 |

## 布局模式

```html
<!-- 外层容器（全宽背景）-->
<table width="100%" style="background:#f0f2f8;padding:24px 0;">
<tr><td align="center">
  <!-- 内层卡片（最大 660px）-->
  <table width="660" style="max-width:660px;background:#fff;border-radius:16px;">
    <tr><td style="padding:24px;">
      <!-- 内容 -->
    </td></tr>
  </table>
</td></tr>
</table>
```

## 多列布局

```html
<table width="100%"><tr>
  <td style="width:33%;padding-right:8px;">列1</td>
  <td style="width:33%;padding:0 4px;">列2</td>
  <td style="width:33%;padding-left:8px;">列3</td>
</tr></table>
```

## 内联 SVG 饼图

```html
<svg xmlns="http://www.w3.org/2000/svg" width="160" height="160" viewBox="0 0 160 160">
  <!-- 弧形扇区 -->
  <path d="M80,80 L80,20 A60,60 0 1,1 ..." fill="#27ae60"/>
  <!-- 中心白圆 -->
  <circle cx="80" cy="80" r="36" fill="#fff"/>
  <!-- 通过率文字 -->
  <text x="80" y="80" text-anchor="middle" font-family="Arial" font-size="15" fill="#2c3e50">93%</text>
</svg>
```

## 进度条（Table 模拟）

```html
<table cellpadding="0" cellspacing="0" width="100%"><tr>
  <td style="background:#27ae60;width:430px;height:10px;border-radius:5px 0 0 5px;"></td>
  <td style="background:#ecf0f1;width:30px;height:10px;border-radius:0 5px 5px 0;"></td>
</tr></table>
```

## 颜色规范（只用实色 hex，禁用 rgba/hsl/CSS 变量）

| 用途 | 颜色 |
|------|------|
| 主色 | `#667eea` |
| 通过 | `#27ae60` |
| 失败 | `#e74c3c` |
| 错误 | `#e67e22` |
| 跳过 | `#95a5a6` |
| 背景 | `#f0f2f8` |
| 卡片 | `#ffffff` |
| 边框 | `#e8ecef` |
| 正文 | `#2c3e50` |
| 次要文字 | `#7f8c8d` |

## 渐变（装饰性）

渐变仅用于 banner 等装饰，始终设置 fallback 实色：

```html
<td style="background:#667eea;background:linear-gradient(135deg,#667eea,#764ba2);">
```

## 发件人头

企业邮件网关中，**带显示名**的 From 字段可能触发"外部邮件"警告：

```
❌ From: 测试报告 <bot@company.com>   ← 触发警告
✅ From: bot@company.com              ← 正常
```

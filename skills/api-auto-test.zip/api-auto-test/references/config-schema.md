# test_config.yaml — 完整 Schema

`test_config.yaml` 是测试运行时的唯一配置入口。每次初始化时调用真实 API 填充动态 ID 字段。

## 通用模板

```yaml
env:
  base_url: "http://<host>/api/v1/<service>"   # 必填
  project_name: "My API"                       # 必填，用于报告表头标题（如 "File API"）
  api_version: "v1.0"                          # 必填，用于报告表头版本号（如 "v1.0"）
  # 认证方式选其一：
  cookie: "<ssoSessionId=...>"                 # Cookie 认证
  token: "<Bearer token>"                      # Token 认证
  invalid_cookie: "ssoSessionId=invalid_xyz"   # 无效认证（用于 401/403 测试）

# 以下字段按项目需要添加/删除：
resources:
  main_resource_id: ""    # 由初始化脚本填充
  secondary_id: ""

sessions:
  session_id: ""

channels:
  channel_id: ""

models:
  current: ""
  switch_target: ""

skills:
  installed: []
  uninstall_target: ""
```

## 初始化调用顺序（参考模式）

```python
def initialize_env():
    # 1. 健康检查
    s, r = GET("/health")
    assert r.get("data", {}).get("status") == "healthy"

    # 2. 获取主资源 ID
    s, r = GET("/resource/list")
    item = r["data"]["list"][0]
    CFG["resources"]["main_resource_id"] = item["id"]

    # 3. 获取 / 创建会话
    s, r = POST(f"/resource/{item['id']}/sessions")
    CFG["sessions"]["session_id"] = r["data"]["session_id"]

    # 4. 保存更新后的 config
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        yaml.dump(CFG, f, allow_unicode=True)
```

## 注意事项

- 破坏性用例（delete / reset）**最后**执行，且执行后需 `rebuild()` 恢复环境
- `invalid_cookie` / `invalid_token` 用于认证失败测试，固定填写一个无效值即可
- 不存在资源 ID 用硬编码字符串，如 `"nonexistent-id-000000"`
- `project_name` / `api_version` / `base_url` 会被报告脚本自动读取用于表头，**务必与接口文档保持一致**，不可留空

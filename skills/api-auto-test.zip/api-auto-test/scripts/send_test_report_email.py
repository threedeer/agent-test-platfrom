#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
API Test Report — Email Sender
从技能目录下的 email_config.yaml 读取配置，将 pytest HTML 报告通过 SMTP 发送。

用法:
    python3 scripts/send_test_report_email.py <html_file> [收件人1,收件人2,...]

    # 发给配置文件中的默认收件人
    python3 scripts/send_test_report_email.py report.html

    # 临时指定收件人（覆盖配置文件）
    python3 scripts/send_test_report_email.py report.html alice@example.com,bob@example.com
"""

import smtplib
import sys
import os
import yaml
from pathlib import Path
from datetime import datetime
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
from email.utils import formatdate, make_msgid

# ── 配置文件路径：技能目录下的 assets/email_config.yaml ────────────
_SCRIPT_DIR = Path(__file__).resolve().parent
_SKILL_DIR = _SCRIPT_DIR.parent
# 配置文件在 assets/ 目录下
_CONFIG_PATH = _SKILL_DIR / "assets" / "email_config.yaml"


def load_config() -> dict:
    if not _CONFIG_PATH.exists():
        print(f"❌ 配置文件不存在: {_CONFIG_PATH}")
        print("   请在技能目录下的 email_config.yaml 中填写 SMTP 和收件人信息")
        sys.exit(1)
    with open(_CONFIG_PATH, encoding="utf-8") as f:
        return yaml.safe_load(f)


def send_report(html_path: str, recipients: list = None,
                attachment_path: str = None,
                project_name: str = "API") -> bool:
    """
    读取 html_path 作为邮件正文（HTML），根据配置文件发送邮件。
    recipients:      收件人列表，传入则覆盖配置文件中的 to 列表。
    attachment_path: 可选附件路径（如原始 report.html）。
    project_name:    项目名，出现在邮件主题中。
    """
    cfg = load_config()

    if not os.path.exists(html_path):
        print(f"❌ HTML 文件不存在: {html_path}")
        return False
    with open(html_path, "r", encoding="utf-8") as f:
        html_body = f.read()
    print(f"📄 已读取报告: {html_path} ({len(html_body) // 1024} KB)")

    smtp_cfg   = cfg.get("smtp", {})
    sender_cfg = cfg.get("sender", {})
    rcpt_cfg   = cfg.get("recipients", {})

    smtp_server  = smtp_cfg.get("server", "")
    smtp_port    = int(smtp_cfg.get("port", 465))
    use_ssl      = smtp_cfg.get("ssl", True)
    sender_email = sender_cfg.get("email", "")
    sender_pass  = sender_cfg.get("password", "")

    to_list  = recipients if recipients else (rcpt_cfg.get("to") or [])
    cc_list  = rcpt_cfg.get("cc") or []
    bcc_list = rcpt_cfg.get("bcc") or []

    if not to_list:
        print("❌ 未配置收件人，请在 email_config.yaml 的 recipients.to 中添加")
        return False

    now     = datetime.now().strftime("%Y-%m-%d")
    subject_tpl = cfg.get("subject", "📊 接口自动化测试报告 {date}")
    subject = subject_tpl.format(date=now, project=project_name)

    sender_domain = sender_email.split("@")[-1] if "@" in sender_email else "localhost"

    msg = MIMEMultipart()
    msg["From"]       = sender_email
    msg["To"]         = ", ".join(to_list)
    msg["Subject"]    = subject
    msg["Date"]       = formatdate(localtime=True)
    msg["Message-ID"] = make_msgid(domain=sender_domain)
    msg["X-Mailer"]   = "APITestRunner/1.0"
    if cc_list:
        msg["Cc"] = ", ".join(cc_list)
    msg.attach(MIMEText(html_body, "html", "utf-8"))

    if attachment_path and os.path.exists(attachment_path):
        with open(attachment_path, "rb") as f:
            part = MIMEBase("application", "octet-stream")
            part.set_payload(f.read())
        encoders.encode_base64(part)
        fname = os.path.basename(attachment_path)
        part.add_header("Content-Disposition", f"attachment; filename={fname}")
        msg.attach(part)
        print(f"📎 已添加附件: {fname}")

    all_recipients = to_list + cc_list + bcc_list

    print(f"📬 收件人: {', '.join(to_list)}")
    if cc_list:
        print(f"   抄送: {', '.join(cc_list)}")
    print(f"🔌 连接 {smtp_server}:{smtp_port} ({'SSL' if use_ssl else 'STARTTLS'}) ...")

    try:
        if use_ssl:
            server_ctx = smtplib.SMTP_SSL(smtp_server, smtp_port)
        else:
            server_ctx = smtplib.SMTP(smtp_server, smtp_port)

        with server_ctx as server:
            if not use_ssl:
                server.starttls()
            server.login(sender_email, sender_pass)
            server.sendmail(sender_email, all_recipients, msg.as_string())

        print("✅ 邮件发送成功！")
        return True

    except smtplib.SMTPAuthenticationError:
        print("❌ 发送失败：用户名或密码错误，请检查 email_config.yaml 中的 sender.password")
        return False
    except smtplib.SMTPConnectError:
        print(f"❌ 发送失败：无法连接 SMTP {smtp_server}:{smtp_port}")
        return False
    except Exception as e:
        print(f"❌ 发送失败：{e}")
        return False


if __name__ == "__main__":
    html_file    = sys.argv[1] if len(sys.argv) > 1 else "report.html"
    cli_rcpt     = [x.strip() for x in sys.argv[2].split(",") if x.strip()] \
                   if len(sys.argv) > 2 else None
    project      = sys.argv[3] if len(sys.argv) > 3 else "API"

    ok = send_report(html_file, recipients=cli_rcpt, project_name=project)
    sys.exit(0 if ok else 1)

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AstronClaw API 测试报告 — 邮件版 HTML 生成器
输出纯内联样式 HTML，兼容 Outlook / Gmail / 企业邮箱 / QQ邮箱
- 无 JS、无外链、无 CSS 类（全内联 style）
- 表格布局，宽度固定 640px
- 图片用内嵌 Base64 SVG 饼图

用法:
    python3 generate_email_report.py
    python3 generate_email_report.py results.json output_email.html
"""

import json, os, sys, math, datetime

SCRIPT_DIR   = os.path.dirname(os.path.abspath(__file__))
PROJECT_DIR  = SCRIPT_DIR
RESULTS_JSON = sys.argv[1] if len(sys.argv) > 1 else os.path.join(PROJECT_DIR, "results.json")
OUT_HTML     = sys.argv[2] if len(sys.argv) > 2 else os.path.join(PROJECT_DIR, "test_report_email.html")

# ── 读取数据 ──────────────────────────────────────────────────────────────
with open(RESULTS_JSON, encoding="utf-8") as f:
    results = json.load(f)

ts       = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
date_str = datetime.datetime.now().strftime("%Y-%m-%d")
total    = len(results)
passed   = sum(1 for r in results if r["status"] == "PASS")
failed   = sum(1 for r in results if r["status"] == "FAIL")
errors   = sum(1 for r in results if r["status"] == "ERROR")
skipped  = sum(1 for r in results if r["status"] == "SKIP")
executed = total - skipped
pass_rate = round(passed / executed * 100, 1) if executed > 0 else 0
total_dur = round(sum(r["duration"] for r in results), 1)
avg_dur   = round(total_dur / executed, 2) if executed else 0

# 按模块聚合
modules = {}
for r in results:
    m = r["module"]
    if m not in modules:
        modules[m] = {"PASS":0,"FAIL":0,"ERROR":0,"SKIP":0}
    modules[m][r["status"]] += 1

bug_list = [r for r in results if r["status"] in ("FAIL","ERROR")]

# ── 工具函数 ──────────────────────────────────────────────────────────────
def esc(s):
    return (s or "").replace("&","&amp;").replace("<","&lt;").replace(">","&gt;")

STATUS_COLOR = {"PASS":"#27ae60","FAIL":"#e74c3c","ERROR":"#e67e22","SKIP":"#95a5a6"}
STATUS_BG    = {"PASS":"#eafaf1","FAIL":"#fdedec","ERROR":"#fef5ec","SKIP":"#f2f3f4"}
STATUS_LBL   = {"PASS":"✅ 通过","FAIL":"❌ 失败","ERROR":"💥 错误","SKIP":"⏭ 跳过"}

def badge(s):
    c  = STATUS_COLOR.get(s,"#aaa")
    bg = STATUS_BG.get(s,"#eee")
    l  = STATUS_LBL.get(s,s)
    return (f'<span style="display:inline-block;padding:2px 10px;border-radius:12px;'
            f'background:{bg};color:{c};font-size:11px;font-weight:700;'
            f'border:1px solid {c}40;white-space:nowrap;">{l}</span>')

# ── 饼图 SVG（内嵌，无外链）───────────────────────────────────────────────
def make_pie_svg(p, f, e, s):
    total_v = p + f + e + s or 1
    slices = [(p,"#27ae60"),(f,"#e74c3c"),(e,"#e67e22"),(s,"#95a5a6")]
    cx, cy, r = 80, 80, 60
    paths = ""
    start = -90.0
    for val, color in slices:
        if val == 0:
            continue
        pct   = val / total_v
        angle = pct * 360
        end   = start + angle
        sr    = math.radians(start)
        er    = math.radians(end)
        x1 = cx + r * math.cos(sr)
        y1 = cy + r * math.sin(sr)
        x2 = cx + r * math.cos(er)
        y2 = cy + r * math.sin(er)
        large = 1 if angle > 180 else 0
        paths += (f'<path d="M{cx},{cy} L{x1:.2f},{y1:.2f} '
                  f'A{r},{r} 0 {large},1 {x2:.2f},{y2:.2f} Z" '
                  f'fill="{color}" stroke="#fff" stroke-width="2"/>')
        start = end
    rate_label = f"{pass_rate}%"
    svg = (f'<svg xmlns="http://www.w3.org/2000/svg" width="160" height="160" '
           f'viewBox="0 0 160 160">'
           f'{paths}'
           f'<circle cx="{cx}" cy="{cy}" r="36" fill="#fff"/>'
           f'<text x="{cx}" y="{cy-6}" text-anchor="middle" '
           f'font-family="Arial,sans-serif" font-size="15" font-weight="bold" fill="#2c3e50">{rate_label}</text>'
           f'<text x="{cx}" y="{cy+12}" text-anchor="middle" '
           f'font-family="Arial,sans-serif" font-size="10" fill="#7f8c8d">通过率</text>'
           f'</svg>')
    return svg

pie_svg = make_pie_svg(passed, failed, errors, skipped)

# ── 进度条（纯 HTML table 模拟）──────────────────────────────────────────
bar_color = "#27ae60" if pass_rate >= 80 else ("#f39c12" if pass_rate >= 50 else "#e74c3c")
bar_w = int(pass_rate * 7.2)   # 720px * rate% (适配更宽布局)
bar_empty = 720 - bar_w

def progress_bar(w_fill, w_empty, color, label):
    return f"""
    <table cellpadding="0" cellspacing="0" border="0" style="width:100%;margin-bottom:8px;">
      <tr>
        <td style="font-size:12px;color:#7f8c8d;padding-right:12px;white-space:nowrap;width:60px;">{label}</td>
        <td style="width:100%;">
          <table cellpadding="0" cellspacing="0" border="0" style="width:100%;background:#ecf0f1;border-radius:6px;height:12px;">
            <tr>
              <td style="background:{color};width:{w_fill}px;height:12px;border-radius:6px 0 0 6px;max-width:100%;"></td>
              <td style="height:12px;"></td>
            </tr>
          </table>
        </td>
        <td style="font-size:13px;font-weight:700;color:{color};padding-left:12px;white-space:nowrap;width:50px;">{pass_rate}%</td>
      </tr>
    </table>"""

progress_html = progress_bar(bar_w, bar_empty, bar_color, "通过率")

# ── 模块汇总行 ────────────────────────────────────────────────────────────
module_rows_html = ""
row_bg = ["#fff", "#f9fafb"]
for i, (mname, md) in enumerate(modules.items()):
    m_exec = md["PASS"] + md["FAIL"] + md["ERROR"]
    m_rate = round(md["PASS"] / m_exec * 100, 1) if m_exec > 0 else 0
    m_color = "#27ae60" if m_rate >= 80 else ("#f39c12" if m_rate >= 50 else "#e74c3c")
    dot_color = m_color
    bg = row_bg[i % 2]
    total_m = m_exec + md["SKIP"]
    m_bar_w = int(m_rate * 1.4)  # max ~140px
    module_rows_html += f"""
    <tr style="background:{bg};">
      <td style="padding:10px 14px;font-size:13px;font-weight:600;color:#2c3e50;border-bottom:1px solid #ecf0f1;">
        <span style="display:inline-block;width:9px;height:9px;border-radius:50%;background:{dot_color};margin-right:8px;vertical-align:middle;"></span>
        {esc(mname)}
      </td>
      <td style="padding:10px 10px;text-align:center;font-size:13px;color:#7f8c8d;border-bottom:1px solid #ecf0f1;">{total_m}</td>
      <td style="padding:10px 10px;text-align:center;font-size:13px;font-weight:700;color:#27ae60;border-bottom:1px solid #ecf0f1;">{md['PASS']}</td>
      <td style="padding:10px 10px;text-align:center;font-size:13px;color:#e74c3c;border-bottom:1px solid #ecf0f1;">{md['FAIL']}</td>
      <td style="padding:10px 10px;text-align:center;font-size:13px;color:#e67e22;border-bottom:1px solid #ecf0f1;">{md['ERROR']}</td>
      <td style="padding:10px 10px;text-align:center;font-size:13px;color:#95a5a6;border-bottom:1px solid #ecf0f1;">{md['SKIP']}</td>
      <td style="padding:10px 14px;border-bottom:1px solid #ecf0f1;">
        <table cellpadding="0" cellspacing="0" border="0"><tr>
          <td style="background:{m_color};width:{m_bar_w}px;height:10px;border-radius:4px;"></td>
          <td style="width:{140-m_bar_w}px;height:10px;background:#ecf0f1;border-radius:0 4px 4px 0;"></td>
          <td style="font-size:12px;font-weight:700;color:{m_color};padding-left:8px;white-space:nowrap;">&nbsp;{m_rate}%</td>
        </tr></table>
      </td>
    </tr>"""

# ── BUG 汇总行 ───────────────────────────────────────────────────────────
bug_rows_html = ""
for i, r in enumerate(bug_list):
    bg = row_bg[i % 2]
    detail_short = esc(r["detail"][:120]) + ("…" if len(r["detail"]) > 120 else "")
    bug_rows_html += f"""
    <tr style="background:{bg};">
      <td style="padding:9px 10px;font-size:11px;color:#7f8c8d;font-family:monospace;border-bottom:1px solid #ecf0f1;white-space:nowrap;">{r['id']}</td>
      <td style="padding:9px 10px;font-size:12px;font-weight:500;color:#2c3e50;border-bottom:1px solid #ecf0f1;">{esc(r['name'])}</td>
      <td style="padding:9px 10px;text-align:center;border-bottom:1px solid #ecf0f1;">{badge(r['status'])}</td>
      <td style="padding:9px 10px;font-size:11px;color:#e74c3c;border-bottom:1px solid #ecf0f1;max-width:260px;">{detail_short}</td>
    </tr>"""

# ── 明细行（仅显示 FAIL/ERROR/非正常SKIP，控制邮件体积）────────────────
# 邮件版不显示全部 149 行，改为分组摘要 + 完整明细作附件提示
# 但为方便直接使用，这里保留全部明细，折叠在模块卡片内
detail_by_module = {}
for r in results:
    m = r["module"]
    if m not in detail_by_module:
        detail_by_module[m] = []
    detail_by_module[m].append(r)

detail_sections_html = ""
for mname, rows in detail_by_module.items():
    md = modules[mname]
    m_exec = md["PASS"] + md["FAIL"] + md["ERROR"]
    m_rate = round(md["PASS"] / m_exec * 100, 1) if m_exec > 0 else 0
    m_color = "#27ae60" if m_rate >= 80 else ("#f39c12" if m_rate >= 50 else "#e74c3c")
    rows_html = ""
    for j, r in enumerate(rows):
        rbg = row_bg[j % 2]
        sc  = STATUS_COLOR.get(r["status"], "#aaa")
        sbg = STATUS_BG.get(r["status"], "#eee")
        slbl= STATUS_LBL.get(r["status"], r["status"])
        dur_c = "#e74c3c" if r["duration"]>30 else ("#f39c12" if r["duration"]>5 else "#27ae60")
        det = ""
        if r["detail"] and r["status"] in ("FAIL","ERROR","SKIP") and r["detail"]:
            det = (f'<br><span style="font-size:10px;color:#7f8c8d;">'
                   f'{esc(r["detail"][:100])}{"…" if len(r["detail"])>100 else ""}</span>')
        rows_html += f"""
        <tr style="background:{rbg};">
          <td style="padding:7px 10px;font-size:11px;color:#7f8c8d;font-family:monospace;border-bottom:1px solid #ecf0f1;white-space:nowrap;">{r['id']}</td>
          <td style="padding:7px 10px;font-size:12px;color:#2c3e50;border-bottom:1px solid #ecf0f1;">{esc(r['name'])}{det}</td>
          <td style="padding:7px 10px;text-align:center;border-bottom:1px solid #ecf0f1;">
            <span style="display:inline-block;padding:2px 9px;border-radius:10px;background:{sbg};color:{sc};font-size:11px;font-weight:700;border:1px solid {sc}40;">{slbl}</span>
          </td>
          <td style="padding:7px 10px;text-align:center;font-size:11px;font-weight:600;color:{dur_c};border-bottom:1px solid #ecf0f1;white-space:nowrap;">{r['duration']}s</td>
        </tr>"""

    detail_sections_html += f"""
    <table cellpadding="0" cellspacing="0" border="0" style="width:100%;margin-bottom:16px;border-radius:8px;overflow:hidden;border:1px solid #e8ecef;">
      <thead>
        <tr style="background:linear-gradient(90deg,{m_color}18,{m_color}08);">
          <td colspan="4" style="padding:10px 14px;">
            <span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:{m_color};margin-right:8px;vertical-align:middle;"></span>
            <span style="font-size:13px;font-weight:700;color:#2c3e50;">{esc(mname)}</span>
            <span style="margin-left:10px;font-size:11px;color:{m_color};font-weight:600;">{m_rate}% 通过</span>
            <span style="margin-left:8px;font-size:11px;color:#7f8c8d;">({md['PASS']} 通过 / {md['FAIL']+md['ERROR']} 失败 / {md['SKIP']} 跳过)</span>
          </td>
        </tr>
        <tr style="background:#f8f9fa;">
          <th style="padding:7px 10px;font-size:11px;color:#7f8c8d;font-weight:600;text-align:left;border-bottom:2px solid #e2e8f0;width:110px;">用例 ID</th>
          <th style="padding:7px 10px;font-size:11px;color:#7f8c8d;font-weight:600;text-align:left;border-bottom:2px solid #e2e8f0;">用例名称</th>
          <th style="padding:7px 10px;font-size:11px;color:#7f8c8d;font-weight:600;text-align:center;border-bottom:2px solid #e2e8f0;width:80px;">状态</th>
          <th style="padding:7px 10px;font-size:11px;color:#7f8c8d;font-weight:600;text-align:center;border-bottom:2px solid #e2e8f0;width:60px;">耗时</th>
        </tr>
      </thead>
      <tbody>
        {rows_html}
      </tbody>
    </table>"""

# ══════════════════════════════════════════════════════════════════════════
# 组装完整邮件 HTML
# ══════════════════════════════════════════════════════════════════════════
# ── 报告元信息：从 test_config.yaml 读取，也可通过 argv[3/4/5] 覆盖 ──────────
import yaml as _yaml
_cfg_path = os.path.join(PROJECT_DIR, "test_config.yaml")
_cfg_env  = {}
if os.path.exists(_cfg_path):
    with open(_cfg_path, encoding="utf-8") as _f:
        _cfg_env = _yaml.safe_load(_f).get("env", {})
project_name = sys.argv[3] if len(sys.argv) > 3 else _cfg_env.get("project_name", "API")
api_version  = sys.argv[4] if len(sys.argv) > 4 else _cfg_env.get("api_version",  "v1.0")
base_url     = sys.argv[5] if len(sys.argv) > 5 else _cfg_env.get("base_url",      "")

html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>{project_name} 测试报告 {date_str}</title>
<style type="text/css">
/* 响应式：在邮件客户端宽屏下撑满，窄屏自动收窄 */
@media only screen and (max-width:640px) {{
  .main-card {{ width:100% !important; }}
  .stat-td   {{ display:block !important; width:48% !important; margin-bottom:8px; float:left; }}
  .stat-clear{{ clear:both; display:block; }}
}}
</style>
</head>
<body style="margin:0;padding:0;background:#f0f2f8;font-family:'PingFang SC','Microsoft YaHei',Arial,sans-serif;">

<!-- ══ 外层容器 ══ -->
<table cellpadding="0" cellspacing="0" border="0" width="100%" style="background:#f0f2f8;padding:24px 0;">
<tr><td align="center">

<!-- ══ 主体卡片：自适应宽度，最宽 960px ══ -->
<table cellpadding="0" cellspacing="0" border="0" width="96%" class="main-card"
       style="max-width:960px;background:#fff;border-radius:16px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,.08);">

  <!-- ── Banner ── -->
  <tr>
    <td style="background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);padding:44px 48px 34px;text-align:center;">
      <div style="font-size:24px;font-weight:700;color:#fff;letter-spacing:2px;margin-bottom:10px;">
        📊 {project_name} 测试报告
      </div>
      <div style="font-size:13px;color:rgba(255,255,255,.8);letter-spacing:.5px;">
        生成时间：{ts} &nbsp;·&nbsp; 环境：{base_url} &nbsp;·&nbsp; 版本：{api_version}
      </div>
    </td>
  </tr>

  <!-- ── 数字统计卡片 ── -->
  <tr>
    <td style="padding:28px 36px 10px;">
      <table cellpadding="0" cellspacing="0" border="0" width="100%">
        <tr>
          <td class="stat-td" style="padding:0 8px 14px 0;">
            <table cellpadding="0" cellspacing="0" border="0" width="100%"
                   style="border-radius:10px;border-top:4px solid #667eea;box-shadow:0 2px 10px rgba(0,0,0,.07);background:#fff;">
              <tr><td style="padding:18px 12px;text-align:center;">
                <div style="font-size:26px;font-weight:700;color:#667eea;">{total}</div>
                <div style="font-size:11px;color:#94a3b8;margin-top:6px;">总用例</div>
              </td></tr>
            </table>
          </td>
          <td class="stat-td" style="padding:0 8px 14px;">
            <table cellpadding="0" cellspacing="0" border="0" width="100%"
                   style="border-radius:10px;border-top:4px solid #27ae60;box-shadow:0 2px 10px rgba(0,0,0,.07);background:#fff;">
              <tr><td style="padding:18px 12px;text-align:center;">
                <div style="font-size:26px;font-weight:700;color:#27ae60;">{passed}</div>
                <div style="font-size:11px;color:#94a3b8;margin-top:6px;">✅ 通过</div>
              </td></tr>
            </table>
          </td>
          <td class="stat-td" style="padding:0 8px 14px;">
            <table cellpadding="0" cellspacing="0" border="0" width="100%"
                   style="border-radius:10px;border-top:4px solid #e74c3c;box-shadow:0 2px 10px rgba(0,0,0,.07);background:#fff;">
              <tr><td style="padding:18px 12px;text-align:center;">
                <div style="font-size:26px;font-weight:700;color:#e74c3c;">{failed}</div>
                <div style="font-size:11px;color:#94a3b8;margin-top:6px;">❌ 失败</div>
              </td></tr>
            </table>
          </td>
          <td class="stat-td" style="padding:0 8px 14px;">
            <table cellpadding="0" cellspacing="0" border="0" width="100%"
                   style="border-radius:10px;border-top:4px solid #e67e22;box-shadow:0 2px 10px rgba(0,0,0,.07);background:#fff;">
              <tr><td style="padding:18px 12px;text-align:center;">
                <div style="font-size:26px;font-weight:700;color:#e67e22;">{errors}</div>
                <div style="font-size:11px;color:#94a3b8;margin-top:6px;">💥 错误</div>
              </td></tr>
            </table>
          </td>
          <td class="stat-td" style="padding:0 8px 14px;">
            <table cellpadding="0" cellspacing="0" border="0" width="100%"
                   style="border-radius:10px;border-top:4px solid #95a5a6;box-shadow:0 2px 10px rgba(0,0,0,.07);background:#fff;">
              <tr><td style="padding:18px 12px;text-align:center;">
                <div style="font-size:26px;font-weight:700;color:#95a5a6;">{skipped}</div>
                <div style="font-size:11px;color:#94a3b8;margin-top:6px;">⏭ 跳过</div>
              </td></tr>
            </table>
          </td>
          <td class="stat-td" style="padding:0 0 14px 8px;">
            <table cellpadding="0" cellspacing="0" border="0" width="100%"
                   style="border-radius:10px;border-top:4px solid {bar_color};box-shadow:0 2px 10px rgba(0,0,0,.07);background:#fff;">
              <tr><td style="padding:18px 12px;text-align:center;">
                <div style="font-size:26px;font-weight:700;color:{bar_color};">{pass_rate}%</div>
                <div style="font-size:11px;color:#94a3b8;margin-top:6px;">🎯 通过率</div>
              </td></tr>
            </table>
          </td>
        </tr>
      </table>
    </td>
  </tr>

  <!-- ── 执行概览（饼图 + 进度条）── -->
  <tr>
    <td style="padding:10px 36px 24px;">
      <table cellpadding="0" cellspacing="0" border="0" width="100%"
             style="background:#f8fafc;border-radius:12px;border:1px solid #e8ecef;">
        <tr>
          <td style="padding:24px 20px;vertical-align:middle;width:200px;text-align:center;">
            {pie_svg}
          </td>
          <td style="padding:24px 32px 24px 20px;vertical-align:middle;">
            <div style="font-size:13px;font-weight:700;color:#2c3e50;margin-bottom:14px;">执行概览</div>
            {progress_html}
            <!-- 四个小统计格 -->
            <table cellpadding="0" cellspacing="0" border="0" width="100%" style="margin-top:16px;">
              <tr>
                <td style="padding:12px 14px;background:#fff;border-radius:10px;text-align:center;border:1px solid #e8ecef;">
                  <div style="font-size:16px;font-weight:700;color:#667eea;">{total}</div>
                  <div style="font-size:11px;color:#94a3b8;margin-top:4px;">总数</div>
                </td>
                <td style="width:10px;"></td>
                <td style="padding:12px 14px;background:#fff;border-radius:10px;text-align:center;border:1px solid #e8ecef;">
                  <div style="font-size:16px;font-weight:700;color:{bar_color};">{pass_rate}%</div>
                  <div style="font-size:11px;color:#94a3b8;margin-top:4px;">通过率</div>
                </td>
                <td style="width:10px;"></td>
                <td style="padding:12px 14px;background:#fff;border-radius:10px;text-align:center;border:1px solid #e8ecef;">
                  <div style="font-size:16px;font-weight:700;color:#e74c3c;">{failed+errors}</div>
                  <div style="font-size:11px;color:#94a3b8;margin-top:4px;">需修复</div>
                </td>
                <td style="width:10px;"></td>
                <td style="padding:12px 14px;background:#fff;border-radius:10px;text-align:center;border:1px solid #e8ecef;">
                  <div style="font-size:16px;font-weight:700;color:#74b9ff;">{total_dur}s</div>
                  <div style="font-size:11px;color:#94a3b8;margin-top:4px;">总耗时</div>
                </td>
              </tr>
            </table>
          </td>
        </tr>
        <!-- 图例 -->
        <tr>
          <td colspan="2" style="padding:0 20px 16px;text-align:center;">
            <table cellpadding="0" cellspacing="0" border="0" style="display:inline-table;">
              <tr>
                <td style="padding:0 12px;font-size:11px;color:#7f8c8d;">
                  <span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:#27ae60;margin-right:4px;vertical-align:middle;"></span>通过 {passed}
                </td>
                <td style="padding:0 12px;font-size:11px;color:#7f8c8d;">
                  <span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:#e74c3c;margin-right:4px;vertical-align:middle;"></span>失败 {failed}
                </td>
                <td style="padding:0 12px;font-size:11px;color:#7f8c8d;">
                  <span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:#e67e22;margin-right:4px;vertical-align:middle;"></span>错误 {errors}
                </td>
                <td style="padding:0 12px;font-size:11px;color:#7f8c8d;">
                  <span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:#95a5a6;margin-right:4px;vertical-align:middle;"></span>跳过 {skipped}
                </td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </td>
  </tr>

  <!-- ── 问题汇总（BUG 列表）── -->
  <tr>
    <td style="padding:0 36px 24px;">
      <!-- 区块标题 -->
      <table cellpadding="0" cellspacing="0" border="0" width="100%" style="margin-bottom:12px;">
        <tr>
          <td style="border-left:4px solid #e74c3c;padding:2px 0 2px 12px;">
            <span style="font-size:14px;font-weight:700;color:#2c3e50;">🐛 问题汇总</span>
            <span style="margin-left:8px;font-size:12px;color:#e74c3c;font-weight:600;">{len(bug_list)} 个需修复</span>
          </td>
        </tr>
      </table>
      <table cellpadding="0" cellspacing="0" border="0" width="100%"
             style="border-radius:8px;overflow:hidden;border:1px solid #e8ecef;">
        <thead>
          <tr style="background:#f8f9fa;">
            <th style="padding:9px 10px;font-size:11px;color:#7f8c8d;font-weight:600;text-align:left;border-bottom:2px solid #e2e8f0;width:110px;">用例 ID</th>
            <th style="padding:9px 10px;font-size:11px;color:#7f8c8d;font-weight:600;text-align:left;border-bottom:2px solid #e2e8f0;">用例名称</th>
            <th style="padding:9px 10px;font-size:11px;color:#7f8c8d;font-weight:600;text-align:center;border-bottom:2px solid #e2e8f0;width:80px;">状态</th>
            <th style="padding:9px 10px;font-size:11px;color:#7f8c8d;font-weight:600;text-align:left;border-bottom:2px solid #e2e8f0;">失败原因</th>
          </tr>
        </thead>
        <tbody>
          {bug_rows_html}
        </tbody>
      </table>
    </td>
  </tr>

  <!-- ── 模块汇总 ── -->
  <tr>
    <td style="padding:0 36px 24px;">
      <table cellpadding="0" cellspacing="0" border="0" width="100%" style="margin-bottom:12px;">
        <tr>
          <td style="border-left:4px solid #667eea;padding:2px 0 2px 12px;">
            <span style="font-size:14px;font-weight:700;color:#2c3e50;">📋 模块汇总</span>
            <span style="margin-left:8px;font-size:12px;color:#667eea;font-weight:600;">{len(modules)} 个模块</span>
          </td>
        </tr>
      </table>
      <table cellpadding="0" cellspacing="0" border="0" width="100%"
             style="border-radius:8px;overflow:hidden;border:1px solid #e8ecef;">
        <thead>
          <tr style="background:#f8f9fa;">
            <th style="padding:9px 12px;font-size:11px;color:#7f8c8d;font-weight:600;text-align:left;border-bottom:2px solid #e2e8f0;">模块</th>
            <th style="padding:9px 8px;font-size:11px;color:#7f8c8d;font-weight:600;text-align:center;border-bottom:2px solid #e2e8f0;width:40px;">总计</th>
            <th style="padding:9px 8px;font-size:11px;color:#27ae60;font-weight:600;text-align:center;border-bottom:2px solid #e2e8f0;width:40px;">通过</th>
            <th style="padding:9px 8px;font-size:11px;color:#e74c3c;font-weight:600;text-align:center;border-bottom:2px solid #e2e8f0;width:40px;">失败</th>
            <th style="padding:9px 8px;font-size:11px;color:#e67e22;font-weight:600;text-align:center;border-bottom:2px solid #e2e8f0;width:40px;">错误</th>
            <th style="padding:9px 8px;font-size:11px;color:#95a5a6;font-weight:600;text-align:center;border-bottom:2px solid #e2e8f0;width:40px;">跳过</th>
            <th style="padding:9px 12px;font-size:11px;color:#7f8c8d;font-weight:600;text-align:left;border-bottom:2px solid #e2e8f0;min-width:140px;">通过率</th>
          </tr>
        </thead>
        <tbody>
          {module_rows_html}
        </tbody>
      </table>
    </td>
  </tr>

  <!-- ── 用例明细（按模块）── -->
  <tr>
    <td style="padding:0 36px 24px;">
      <table cellpadding="0" cellspacing="0" border="0" width="100%" style="margin-bottom:12px;">
        <tr>
          <td style="border-left:4px solid #74b9ff;padding:2px 0 2px 12px;">
            <span style="font-size:14px;font-weight:700;color:#2c3e50;">🔍 用例明细</span>
            <span style="margin-left:8px;font-size:12px;color:#74b9ff;font-weight:600;">{total} 条</span>
          </td>
        </tr>
      </table>
      {detail_sections_html}
    </td>
  </tr>

  <!-- ── Footer ── -->
  <tr>
    <td style="background:#f8fafc;padding:20px 36px;border-top:1px solid #e8ecef;text-align:center;">
      <div style="font-size:11px;color:#94a3b8;line-height:1.8;">
        {project_name} Test Runner &nbsp;·&nbsp; 报告生成于 {ts}<br>
        共执行 <strong style="color:#667eea;">{executed}</strong> 条用例 &nbsp;·&nbsp;
        平均耗时 <strong style="color:#74b9ff;">{avg_dur}s</strong> / 条 &nbsp;·&nbsp;
        总耗时 <strong style="color:#74b9ff;">{total_dur}s</strong>
      </div>
    </td>
  </tr>

</table>
<!-- /主体卡片 -->

</td></tr>
</table>
<!-- /外层容器 -->

</body>
</html>"""

with open(OUT_HTML, "w", encoding="utf-8") as f:
    f.write(html)

size_kb = round(os.path.getsize(OUT_HTML) / 1024, 1)
print(f"✅ 邮件版报告已生成: {OUT_HTML} ({size_kb} KB)")
print(f"   Windows: \\\\wsl$\\Ubuntu-20.04{OUT_HTML}")

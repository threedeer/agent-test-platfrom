#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
从 results.json 读取上次测试结果，重新生成精美 HTML 报告
"""
import json, os, datetime, re

SCRIPT_DIR   = os.path.dirname(os.path.abspath(__file__))
import sys as _sys
PROJECT_DIR  = SCRIPT_DIR
RESULTS_JSON = _sys.argv[1] if len(_sys.argv) > 1 else os.path.join(PROJECT_DIR, "results.json")
OUT_HTML     = _sys.argv[2] if len(_sys.argv) > 2 else os.path.join(PROJECT_DIR, "test_report.html")

with open(RESULTS_JSON, encoding="utf-8") as f:
    results = json.load(f)

ts       = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
total    = len(results)
passed   = sum(1 for r in results if r["status"] == "PASS")
failed   = sum(1 for r in results if r["status"] == "FAIL")
errors   = sum(1 for r in results if r["status"] == "ERROR")
skipped  = sum(1 for r in results if r["status"] == "SKIP")
executed = total - skipped
pass_rate = round(passed / executed * 100, 1) if executed > 0 else 0
total_dur = round(sum(r["duration"] for r in results), 1)

# 按模块聚合
modules = {}
for r in results:
    m = r["module"]
    if m not in modules:
        modules[m] = {"PASS":0,"FAIL":0,"ERROR":0,"SKIP":0,"rows":[]}
    modules[m][r["status"]] += 1
    modules[m]["rows"].append(r)

# ── 工具函数 ──────────────────────────────────────
STATUS_COLOR = {"PASS":"#00b894","FAIL":"#d63031","ERROR":"#e17055","SKIP":"#b2bec3"}
STATUS_BG    = {"PASS":"#f0fdf4","FAIL":"#fff5f5","ERROR":"#fff8f5","SKIP":"#f8f9fa"}
STATUS_LABEL = {"PASS":"通过","FAIL":"失败","ERROR":"错误","SKIP":"跳过"}

def badge(s):
    c = STATUS_COLOR.get(s, "#aaa")
    lbl = STATUS_LABEL.get(s, s)
    return (f'<span class="badge badge-{s.lower()}">{lbl}</span>')

def esc(s):
    return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;") if s else ""

# ── 明细行 ────────────────────────────────────────
rows_html = ""
for idx, r in enumerate(results):
    det = esc(r["detail"])
    det_html = ""
    if det:
        det_html = (
            f'<details><summary class="detail-toggle">查看详情 ▾</summary>'
            f'<div class="detail-box">{det[:1000]}</div></details>'
        )
    dur_color = "#d63031" if r["duration"] > 30 else ("#fdcb6e" if r["duration"] > 5 else "#00b894")
    rows_html += f"""
    <tr class="tr-{r['status'].lower()}">
      <td class="td-id">{r['id']}</td>
      <td class="td-name">{esc(r['name'])}</td>
      <td class="td-module">{esc(r['module'])}</td>
      <td class="td-status">{badge(r['status'])}</td>
      <td class="td-dur"><span style="color:{dur_color};font-weight:600;">{r['duration']}s</span></td>
      <td class="td-detail">{det_html}</td>
    </tr>"""

# ── 模块汇总行 ────────────────────────────────────
mod_rows = ""
for mname, md in modules.items():
    m_exec = md["PASS"] + md["FAIL"] + md["ERROR"]
    m_rate = round(md["PASS"] / m_exec * 100, 1) if m_exec > 0 else 0
    bar_color = "#00b894" if m_rate >= 80 else ("#fdcb6e" if m_rate >= 50 else "#d63031")
    bar_w = int(m_rate * 1.5)
    total_m = md["PASS"] + md["FAIL"] + md["ERROR"] + md["SKIP"]
    # 模块状态图标
    if md["FAIL"] + md["ERROR"] == 0:
        m_icon = '<span style="color:#00b894;">●</span>'
    elif m_rate >= 80:
        m_icon = '<span style="color:#fdcb6e;">●</span>'
    else:
        m_icon = '<span style="color:#d63031;">●</span>'

    mod_rows += f"""
    <tr class="mod-row">
      <td style="padding:9px 16px;font-size:.86em;font-weight:600;">{m_icon} {esc(mname)}</td>
      <td style="padding:9px 16px;text-align:center;font-size:.85em;">{total_m}</td>
      <td style="padding:9px 16px;text-align:center;color:#00b894;font-weight:700;">{md['PASS']}</td>
      <td style="padding:9px 16px;text-align:center;color:#d63031;">{md['FAIL']}</td>
      <td style="padding:9px 16px;text-align:center;color:#e17055;">{md['ERROR']}</td>
      <td style="padding:9px 16px;text-align:center;color:#b2bec3;">{md['SKIP']}</td>
      <td style="padding:9px 16px;">
        <div style="display:flex;align-items:center;gap:10px;">
          <div style="flex:1;max-width:160px;background:#eee;border-radius:6px;height:10px;overflow:hidden;">
            <div style="background:{bar_color};height:100%;width:{bar_w}px;border-radius:6px;"></div>
          </div>
          <span style="font-size:.82em;font-weight:700;color:{bar_color};min-width:42px;">{m_rate}%</span>
        </div>
      </td>
    </tr>"""

# ── BUG 列表 ──────────────────────────────────────
bug_rows = ""
bug_list = [r for r in results if r["status"] in ("FAIL","ERROR")]
for r in bug_list:
    bug_rows += f"""
    <tr>
      <td style="padding:8px 14px;font-size:.82em;color:#636e72;white-space:nowrap;">{r['id']}</td>
      <td style="padding:8px 14px;font-size:.84em;font-weight:500;">{esc(r['name'])}</td>
      <td style="padding:8px 14px;text-align:center;">{badge(r['status'])}</td>
      <td style="padding:8px 14px;font-size:.8em;color:#636e72;max-width:400px;">
        <span style="color:#d63031;">{esc(r['detail'][:120])}{'...' if len(r['detail'])>120 else ''}</span>
      </td>
    </tr>"""

# ── 饼图 SVG（简易） ─────────────────────────────
def pie_svg(p, f, e, s):
    total_v = p + f + e + s
    if total_v == 0: total_v = 1
    def arc(val, start, color, label):
        pct = val / total_v
        if pct == 0: return ""
        angle = pct * 360
        r = 70
        cx, cy = 90, 90
        start_r = (start - 90) * 3.14159 / 180
        end_r   = (start + angle - 90) * 3.14159 / 180
        x1 = cx + r * __import__("math").cos(start_r)
        y1 = cy + r * __import__("math").sin(start_r)
        x2 = cx + r * __import__("math").cos(end_r)
        y2 = cy + r * __import__("math").sin(end_r)
        large = 1 if angle > 180 else 0
        mid_r = (start + angle/2 - 90) * 3.14159 / 180
        lx = cx + (r+22) * __import__("math").cos(mid_r)
        ly = cy + (r+22) * __import__("math").sin(mid_r)
        path = f'<path d="M{cx},{cy} L{x1:.1f},{y1:.1f} A{r},{r} 0 {large},1 {x2:.1f},{y2:.1f} Z" fill="{color}" stroke="#fff" stroke-width="2"/>'
        txt  = f'<text x="{lx:.1f}" y="{ly:.1f}" text-anchor="middle" font-size="11" fill="{color}" font-weight="600">{val}</text>' if pct > 0.04 else ""
        return path + txt
    a = 0
    svg = f'<svg width="180" height="180" viewBox="0 0 180 180">'
    svg += arc(p, a, "#00b894", "通过"); a += p/total_v*360
    svg += arc(f, a, "#d63031", "失败"); a += f/total_v*360
    svg += arc(e, a, "#e17055", "错误"); a += e/total_v*360
    svg += arc(s, a, "#b2bec3", "跳过")
    svg += f'<circle cx="90" cy="90" r="40" fill="#fff"/>'
    svg += f'<text x="90" y="86" text-anchor="middle" font-size="18" fill="#2d3436" font-weight="700">{pass_rate}%</text>'
    svg += f'<text x="90" y="102" text-anchor="middle" font-size="10" fill="#636e72">通过率</text>'
    svg += '</svg>'
    return svg

pie = pie_svg(passed, failed, errors, skipped)

# ── 进度条颜色 ───────────────────────────────────
bar_main_color = "#00b894" if pass_rate >= 80 else ("#fdcb6e" if pass_rate >= 50 else "#d63031")

# ══════════════════════════════════════════════════
# 生成完整 HTML
# ══════════════════════════════════════════════════
# ── 报告元信息：从 test_config.yaml 读取，也可通过 argv[3/4/5] 覆盖 ──────────
import sys as _sys2, yaml as _yaml
_cfg_path = os.path.join(PROJECT_DIR, "test_config.yaml")
_cfg_env  = {}
if os.path.exists(_cfg_path):
    with open(_cfg_path, encoding="utf-8") as _f:
        _cfg_env = _yaml.safe_load(_f).get("env", {})
project_name = _sys2.argv[3] if len(_sys2.argv) > 3 else _cfg_env.get("project_name", "API")
api_version  = _sys2.argv[4] if len(_sys2.argv) > 4 else _cfg_env.get("api_version",  "v1.0")
base_url     = _sys2.argv[5] if len(_sys2.argv) > 5 else _cfg_env.get("base_url",      "")

html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{project_name} 测试报告 · {ts[:10]}</title>
<style>
/* ── Reset & Base ── */
*{{box-sizing:border-box;margin:0;padding:0;}}
html{{scroll-behavior:smooth;}}
body{{
  font-family:"PingFang SC","Helvetica Neue","Microsoft YaHei",Arial,sans-serif;
  background:#f0f2f8;
  color:#2d3436;
  font-size:14px;
  line-height:1.6;
}}

/* ── Layout ── */
.page-header{{
  background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);
  color:#fff;
  padding:48px 0 36px;
  text-align:center;
  position:relative;
  overflow:hidden;
}}
.page-header::before{{
  content:'';
  position:absolute;
  width:300px;height:300px;
  background:rgba(255,255,255,.06);
  border-radius:50%;
  top:-80px;left:-60px;
}}
.page-header::after{{
  content:'';
  position:absolute;
  width:200px;height:200px;
  background:rgba(255,255,255,.06);
  border-radius:50%;
  bottom:-50px;right:80px;
}}
.header-title{{font-size:2em;font-weight:700;letter-spacing:3px;position:relative;z-index:1;}}
.header-meta{{margin-top:12px;font-size:.88em;opacity:.8;position:relative;z-index:1;letter-spacing:.5px;}}
.header-meta span{{margin:0 10px;}}

.container{{max-width:1360px;margin:0 auto;padding:32px 24px;}}

/* ── Cards ── */
.stat-grid{{
  display:grid;
  grid-template-columns:repeat(7,1fr);
  gap:14px;
  margin-bottom:28px;
}}
@media(max-width:900px){{.stat-grid{{grid-template-columns:repeat(4,1fr);}}}}
@media(max-width:500px){{.stat-grid{{grid-template-columns:repeat(2,1fr);}}}}

.stat-card{{
  background:#fff;
  border-radius:16px;
  padding:20px 16px;
  text-align:center;
  box-shadow:0 2px 16px rgba(0,0,0,.06);
  border-top:4px solid transparent;
  transition:transform .2s,box-shadow .2s;
}}
.stat-card:hover{{transform:translateY(-3px);box-shadow:0 6px 24px rgba(0,0,0,.1);}}
.stat-card .num{{font-size:2.2em;font-weight:700;line-height:1.2;}}
.stat-card .lbl{{font-size:.8em;color:#94a3b8;margin-top:6px;font-weight:500;}}

/* ── Section ── */
.section{{
  background:#fff;
  border-radius:16px;
  padding:28px 24px;
  margin-bottom:24px;
  box-shadow:0 2px 16px rgba(0,0,0,.05);
}}
.section-header{{
  display:flex;
  align-items:center;
  justify-content:space-between;
  margin-bottom:20px;
  padding-bottom:14px;
  border-bottom:1px solid #f1f5f9;
}}
.section-title{{
  font-size:1em;
  font-weight:700;
  color:#2d3436;
  display:flex;
  align-items:center;
  gap:8px;
}}
.section-title .icon{{
  width:28px;height:28px;
  background:linear-gradient(135deg,#667eea,#764ba2);
  border-radius:8px;
  display:flex;align-items:center;justify-content:center;
  font-size:.9em;
  flex-shrink:0;
}}

/* ── Overview ── */
.overview-grid{{display:grid;grid-template-columns:200px 1fr;gap:32px;align-items:center;}}
@media(max-width:600px){{.overview-grid{{grid-template-columns:1fr;}}}}
.progress-block label{{font-size:.82em;color:#94a3b8;margin-bottom:6px;display:block;font-weight:500;}}
.progress-bar{{background:#f1f5f9;border-radius:8px;height:14px;overflow:hidden;margin-bottom:14px;}}
.progress-fill{{height:100%;border-radius:8px;transition:width .8s ease;}}
.overview-stats{{display:grid;grid-template-columns:repeat(2,1fr);gap:12px;margin-top:16px;}}
.ov-item{{background:#f8fafc;border-radius:10px;padding:12px 14px;}}
.ov-item .ov-val{{font-size:1.3em;font-weight:700;}}
.ov-item .ov-lbl{{font-size:.78em;color:#94a3b8;margin-top:2px;}}

/* ── Table ── */
.table-wrap{{overflow-x:auto;border-radius:10px;border:1px solid #f1f5f9;}}
table{{width:100%;border-collapse:collapse;}}
thead tr{{background:#f8fafc;}}
th{{
  padding:11px 14px;
  font-size:.8em;
  font-weight:700;
  color:#64748b;
  text-align:left;
  border-bottom:2px solid #e2e8f0;
  white-space:nowrap;
  letter-spacing:.3px;
  text-transform:uppercase;
}}
.tr-pass{{background:#fff;}}
.tr-fail{{background:#fffafa;}}
.tr-error{{background:#fffaf8;}}
.tr-skip{{background:#fafafa;}}
tbody tr:hover{{background:#f8faff!important;}}
tbody tr{{border-bottom:1px solid #f1f5f9;}}
tbody tr:last-child{{border-bottom:none;}}
td{{padding:10px 14px;vertical-align:middle;}}
.td-id{{font-size:.78em;color:#94a3b8;white-space:nowrap;font-family:monospace;font-size:.82em;}}
.td-name{{font-size:.86em;font-weight:500;}}
.td-module{{font-size:.78em;color:#64748b;white-space:nowrap;}}
.td-status{{text-align:center;white-space:nowrap;}}
.td-dur{{text-align:center;white-space:nowrap;font-size:.82em;}}
.td-detail{{font-size:.8em;max-width:300px;}}

/* ── Badge ── */
.badge{{
  display:inline-block;
  padding:3px 11px;
  border-radius:20px;
  font-size:.75em;
  font-weight:700;
  letter-spacing:.5px;
}}
.badge-pass{{background:#dcfce7;color:#16a34a;}}
.badge-fail{{background:#fee2e2;color:#dc2626;}}
.badge-error{{background:#fed7aa;color:#ea580c;}}
.badge-skip{{background:#f1f5f9;color:#64748b;}}

/* ── Detail expand ── */
.detail-toggle{{
  cursor:pointer;
  color:#667eea;
  font-size:.8em;
  list-style:none;
  outline:none;
  font-weight:500;
}}
.detail-toggle::-webkit-details-marker{{display:none;}}
.detail-box{{
  margin-top:6px;
  padding:8px 10px;
  background:#1e293b;
  color:#94a3b8;
  border-radius:6px;
  font-family:monospace;
  font-size:.76em;
  white-space:pre-wrap;
  word-break:break-all;
  line-height:1.5;
  max-height:200px;
  overflow-y:auto;
}}

/* ── Module table ── */
.mod-row td{{transition:background .15s;}}
.mod-row:hover td{{background:#f8faff;}}

/* ── Bug section ── */
.bug-item{{
  border-left:3px solid #d63031;
  padding:10px 14px;
  margin-bottom:10px;
  background:#fffafa;
  border-radius:0 8px 8px 0;
}}
.bug-item .bug-id{{font-size:.78em;color:#94a3b8;font-family:monospace;}}
.bug-item .bug-name{{font-size:.88em;font-weight:600;margin:3px 0;}}
.bug-item .bug-detail{{font-size:.8em;color:#dc2626;}}

/* ── Legend ── */
.legend{{display:flex;gap:16px;flex-wrap:wrap;}}
.legend-item{{display:flex;align-items:center;gap:6px;font-size:.82em;color:#64748b;}}
.legend-dot{{width:10px;height:10px;border-radius:50%;}}

/* ── Footer ── */
.footer{{
  text-align:center;
  padding:24px 0 36px;
  color:#94a3b8;
  font-size:.8em;
}}

/* ── Filter bar ── */
.filter-bar{{
  display:flex;gap:8px;flex-wrap:wrap;margin-bottom:16px;
}}
.filter-btn{{
  border:1px solid #e2e8f0;
  background:#fff;
  border-radius:20px;
  padding:5px 14px;
  font-size:.8em;
  cursor:pointer;
  transition:all .2s;
  font-weight:500;
  color:#64748b;
}}
.filter-btn:hover,.filter-btn.active{{
  background:#667eea;
  color:#fff;
  border-color:#667eea;
}}
</style>
</head>
<body>

<!-- ══ Header ══ -->
<div class="page-header">
  <div class="header-title">📊 {project_name} 测试报告</div>
  <div class="header-meta">
    <span>📅 {ts}</span>
    <span>📦 接口版本 {api_version}</span>
    <span>🌐 {base_url}</span>
  </div>
</div>

<div class="container">

<!-- ══ 汇总数字卡片 ══ -->
<div class="stat-grid" style="margin-top:32px;">
  <div class="stat-card" style="border-top-color:#667eea;">
    <div class="num" style="color:#667eea;">{total}</div>
    <div class="lbl">用例总数</div>
  </div>
  <div class="stat-card" style="border-top-color:#00b894;">
    <div class="num" style="color:#00b894;">{passed}</div>
    <div class="lbl">✅ 通过</div>
  </div>
  <div class="stat-card" style="border-top-color:#d63031;">
    <div class="num" style="color:#d63031;">{failed}</div>
    <div class="lbl">❌ 失败</div>
  </div>
  <div class="stat-card" style="border-top-color:#e17055;">
    <div class="num" style="color:#e17055;">{errors}</div>
    <div class="lbl">💥 错误</div>
  </div>
  <div class="stat-card" style="border-top-color:#b2bec3;">
    <div class="num" style="color:#b2bec3;">{skipped}</div>
    <div class="lbl">⏭ 跳过</div>
  </div>
  <div class="stat-card" style="border-top-color:{bar_main_color};">
    <div class="num" style="color:{bar_main_color};">{pass_rate}%</div>
    <div class="lbl">🎯 通过率</div>
  </div>
  <div class="stat-card" style="border-top-color:#74b9ff;">
    <div class="num" style="color:#74b9ff;">{total_dur}s</div>
    <div class="lbl">⏱ 总耗时</div>
  </div>
</div>

<!-- ══ 执行概览 ══ -->
<div class="section">
  <div class="section-header">
    <div class="section-title">
      <div class="icon">🏆</div>
      执行概览
    </div>
    <div class="legend">
      <div class="legend-item"><div class="legend-dot" style="background:#00b894;"></div>通过 {passed}</div>
      <div class="legend-item"><div class="legend-dot" style="background:#d63031;"></div>失败 {failed}</div>
      <div class="legend-item"><div class="legend-dot" style="background:#e17055;"></div>错误 {errors}</div>
      <div class="legend-item"><div class="legend-dot" style="background:#b2bec3;"></div>跳过 {skipped}</div>
    </div>
  </div>

  <div class="overview-grid">
    <!-- 左：饼图 -->
    <div style="display:flex;justify-content:center;">
      {pie}
    </div>
    <!-- 右：进度信息 -->
    <div>
      <div class="progress-block">
        <label>通过率 — 已执行 {executed} 条，跳过 {skipped} 条</label>
        <div class="progress-bar">
          <div class="progress-fill" style="width:{pass_rate}%;background:{bar_main_color};"></div>
        </div>
        <label>总耗时 — {total_dur} 秒</label>
        <div class="progress-bar">
          <div class="progress-fill" style="width:{min(int(total_dur/300*100),100)}%;background:#74b9ff;"></div>
        </div>
      </div>
      <div class="overview-stats">
        <div class="ov-item">
          <div class="ov-val" style="color:#667eea;">{total}</div>
          <div class="ov-lbl">总用例数</div>
        </div>
        <div class="ov-item">
          <div class="ov-val" style="color:#00b894;">{pass_rate}%</div>
          <div class="ov-lbl">执行通过率</div>
        </div>
        <div class="ov-item">
          <div class="ov-val" style="color:#d63031;">{failed + errors}</div>
          <div class="ov-lbl">需修复问题数</div>
        </div>
        <div class="ov-item">
          <div class="ov-val" style="color:#74b9ff;">{round(total_dur/executed,2) if executed else 0}s</div>
          <div class="ov-lbl">平均用例耗时</div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- ══ 失败/错误 BUG 汇总 ══ -->
{"" if not bug_list else f'''
<div class="section">
  <div class="section-header">
    <div class="section-title">
      <div class="icon">🐛</div>
      问题汇总（{len(bug_list)} 个）
    </div>
  </div>
  <div class="table-wrap">
  <table>
    <thead>
      <tr>
        <th>用例 ID</th>
        <th>用例名称</th>
        <th style="text-align:center;">状态</th>
        <th>失败原因</th>
      </tr>
    </thead>
    <tbody>
      {bug_rows}
    </tbody>
  </table>
  </div>
</div>
'''}

<!-- ══ 模块汇总 ══ -->
<div class="section">
  <div class="section-header">
    <div class="section-title">
      <div class="icon">📋</div>
      模块汇总（{len(modules)} 个模块）
    </div>
  </div>
  <div class="table-wrap">
  <table>
    <thead>
      <tr>
        <th>模块名称</th>
        <th style="text-align:center;">总计</th>
        <th style="text-align:center;">通过</th>
        <th style="text-align:center;">失败</th>
        <th style="text-align:center;">错误</th>
        <th style="text-align:center;">跳过</th>
        <th style="min-width:220px;">通过率</th>
      </tr>
    </thead>
    <tbody>
      {mod_rows}
    </tbody>
  </table>
  </div>
</div>

<!-- ══ 用例明细 ══ -->
<div class="section">
  <div class="section-header">
    <div class="section-title">
      <div class="icon">🔍</div>
      用例明细（{total} 条）
    </div>
  </div>

  <!-- 筛选按钮 -->
  <div class="filter-bar">
    <button class="filter-btn active" onclick="filterRows('all')">全部 {total}</button>
    <button class="filter-btn" onclick="filterRows('pass')" style="--c:#00b894;">通过 {passed}</button>
    <button class="filter-btn" onclick="filterRows('fail')" style="--c:#d63031;">失败 {failed}</button>
    <button class="filter-btn" onclick="filterRows('error')" style="--c:#e17055;">错误 {errors}</button>
    <button class="filter-btn" onclick="filterRows('skip')" style="--c:#b2bec3;">跳过 {skipped}</button>
  </div>

  <div class="table-wrap">
  <table id="detail-table">
    <thead>
      <tr>
        <th style="min-width:110px;">用例 ID</th>
        <th style="min-width:200px;">用例名称</th>
        <th style="min-width:150px;">所属模块</th>
        <th style="text-align:center;min-width:80px;">状态</th>
        <th style="text-align:center;min-width:70px;">耗时</th>
        <th style="min-width:160px;">详情</th>
      </tr>
    </thead>
    <tbody id="detail-tbody">
      {rows_html}
    </tbody>
  </table>
  </div>
</div>

</div><!--.container-->

<!-- ══ Footer ══ -->
<div class="footer">
  {project_name} Test Runner &nbsp;·&nbsp; 报告生成于 {ts} &nbsp;·&nbsp; 共执行 {executed} 条用例
</div>

<script>
function filterRows(type) {{
  document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
  event.target.classList.add('active');
  const rows = document.querySelectorAll('#detail-tbody tr');
  rows.forEach(row => {{
    if (type === 'all') {{ row.style.display = ''; return; }}
    const hasCls = row.classList.contains('tr-' + type);
    row.style.display = hasCls ? '' : 'none';
  }});
}}
</script>
</body>
</html>"""

with open(OUT_HTML, "w", encoding="utf-8") as f:
    f.write(html)

size_kb = round(os.path.getsize(OUT_HTML)/1024, 1)
print(f"✅ 报告已生成: {OUT_HTML} ({size_kb} KB)")
print(f"   Windows 路径: \\\\wsl$\\Ubuntu-20.04{OUT_HTML}")
